# NOVA — Social, reimagined

แอปโซเชียลบนมือถือ (React + TypeScript + Vite) แพ็กเป็นแอป Android ด้วย Capacitor

## โครงสร้าง

```
index.html            จุดเริ่ม + meta/OG/PWA + ตั้งธีมก่อนวาดหน้าจอ
public/               ไอคอน, manifest, service worker, privacy/terms (สร้างอัตโนมัติ), og-image
resources/            ไอคอนต้นฉบับ/adaptive/splash สำหรับ Android
store-assets/         ไอคอน 512 และ feature graphic สำหรับ Play
docs/                 LAUNCH_AND_LONGEVITY.md — เช็กลิสต์ Play Store และแนวทางความทนทาน
scripts/              gen-legal.ts สร้างหน้านโยบายจากข้อความในแอป
tests/                เทสต์ของ logic ล้วน (format, routes, migrate)
src/
  main.tsx, App.tsx   ทางเข้า, provider, เลย์เอาต์หลัก, ErrorBoundary
  config.ts           ค่าคงที่และตัวแปร env
  types.ts            ชนิดข้อมูลกลาง
  data/seed.ts        ข้อมูลตัวอย่าง (แทนที่ด้วย API เมื่อมี backend)
  store/              state กลาง + บันทึกลงเครื่อง (AppStore), อัปเกรด/ตรวจข้อมูล (migrate)
  i18n/               ข้อความไทย/อังกฤษ และเอกสารกฎหมาย
  lib/                format, image (ย่อรูป+ลบ EXIF), router (hash), share, backup, pwa, storage
  services/novaAi.ts  ตัวเชื่อม NOVA AI
  components/         Avatar, SafeImage, Sheet, PostCard, TabBar ฯลฯ
  screens/            Home, Reels (ไฮไลต์), Explore, AI, Messages/Thread, Profile
  sheets/             สร้างโพสต์, คอมเมนต์, เมนูโพสต์/รายงาน, โปรไฟล์/ตั้งค่า/กฎหมาย, เรื่องราว
  styles/             base (โทเคนสี/ธีม), components, screens
```
