import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseHash, paths } from '../src/lib/routes.ts';

test('parseHash maps hashes to routes', () => {
  assert.deepEqual(parseHash(''), { name: 'home' });
  assert.deepEqual(parseHash('#/'), { name: 'home' });
  assert.deepEqual(parseHash('#/explore'), { name: 'explore' });
  assert.deepEqual(parseHash('#/reels'), { name: 'reels' });
  assert.deepEqual(parseHash('#/messages'), { name: 'messages' });
  assert.deepEqual(parseHash('#/messages/sarah'), { name: 'thread', id: 'sarah' });
  assert.deepEqual(parseHash('#/nope'), { name: 'home' });
});

test('thread ids round-trip and bad encodings do not throw', () => {
  const id = 'a b/ç';
  assert.deepEqual(parseHash('#' + paths.thread(id)), { name: 'thread', id });
  assert.deepEqual(parseHash('#/messages/%E0%A4%A'), { name: 'thread', id: '%E0%A4%A' });
});
