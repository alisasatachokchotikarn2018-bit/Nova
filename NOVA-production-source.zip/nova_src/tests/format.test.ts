import { test } from 'node:test';
import assert from 'node:assert/strict';
import { compact, firstChar, initials, timeAgo } from '../src/lib/format.ts';

test('compact abbreviates large numbers', () => {
  assert.equal(compact(0), '0');
  assert.equal(compact(999), '999');
  assert.equal(compact(12_400), '12.4K');
  assert.equal(compact(2_500_000), '2.5M');
  assert.equal(compact(-5), '0');
});

test('timeAgo picks a sensible unit in both languages', () => {
  const now = Date.UTC(2027, 0, 10, 12, 0, 0);
  assert.equal(timeAgo(now - 10_000, 'th', now), 'เมื่อสักครู่');
  assert.equal(timeAgo(now - 10_000, 'en', now), 'just now');
  assert.match(timeAgo(now - 5 * 60_000, 'en', now), /5/);
  assert.match(timeAgo(now - 3 * 3_600_000, 'th', now), /3/);
  assert.match(timeAgo(now - 2 * 86_400_000, 'en', now), /2/);
});

test('initials handle Latin, Thai and mixed names', () => {
  assert.equal(initials('Maya Lin'), 'ML');
  assert.equal(initials('NOVA'), 'N');
  assert.equal(initials('ผู้ใช้ NOVA'), 'ผ');
  assert.equal(initials('เอ็นโอวา'), 'อ');
  assert.equal(firstChar('   '), '?');
});
