import { test } from 'node:test';
import assert from 'node:assert/strict';
import { restoreState, SCHEMA_VERSION } from '../src/store/migrate.ts';
import type { State } from '../src/store/AppStore.tsx';

const base: State = {
  profile: { name: 'Base', handle: 'base1234', bio: '', avatar: '' },
  myPosts: [],
  comments: {},
  liked: [],
  saved: [],
  hidden: [],
  blocked: [],
  following: [],
  reports: [],
  threads: { sarah: [{ id: 's1', from: 'them', text: 'hi', at: 1 }] },
  unread: { sarah: 1 },
  seenStories: [],
  lang: 'th',
  theme: 'system',
};

const PIXEL =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

test('garbage input falls back to the defaults', () => {
  for (const bad of [null, undefined, 42, 'x', [], true]) assert.deepEqual(restoreState(bad, base), base);
});

test('unversioned (v0) saves still load', () => {
  const out = restoreState({ profile: { name: 'Old User', handle: 'old.user' }, liked: ['p1'], lang: 'en' }, base);
  assert.equal(out.profile.name, 'Old User');
  assert.deepEqual(out.liked, ['p1']);
  assert.equal(out.lang, 'en');
  assert.equal(out.theme, 'system');
  assert.ok(SCHEMA_VERSION >= 1);
});

test('wrong types are dropped instead of crashing the app', () => {
  const out = restoreState({ liked: 'nope', saved: [1, 'p2', null], threads: 5, lang: 'fr', theme: 9, profile: 7 }, base);
  assert.deepEqual(out.liked, []);
  assert.deepEqual(out.saved, ['p2']);
  assert.deepEqual(out.threads, base.threads);
  assert.equal(out.lang, 'th');
  assert.equal(out.theme, 'system');
  assert.equal(out.profile.name, 'Base');
});

test('only inline images are accepted for own posts and avatars (no remote URLs)', () => {
  const out = restoreState(
    {
      profile: { name: 'A', handle: 'abc', avatar: 'https://evil.example/x.png' },
      myPosts: [
        { id: 'u1', image: PIXEL, caption: 'ok' },
        { id: 'u2', image: 'javascript:alert(1)', caption: 'bad' },
        { id: 'u3', image: 'https://evil.example/t.gif', caption: 'bad' },
        { id: 'u4', image: '', caption: 'text only' },
        { image: PIXEL },
      ],
    },
    base,
  );
  assert.equal(out.profile.avatar, '');
  assert.deepEqual(out.myPosts.map((p) => p.id), ['u1', 'u4']);
});

test('lengths are clamped', () => {
  const out = restoreState({ profile: { name: 'x'.repeat(500), handle: 'y'.repeat(500), bio: 'z'.repeat(500) } }, base);
  assert.equal(out.profile.name.length, 30);
  assert.equal(out.profile.handle.length, 20);
  assert.equal(out.profile.bio.length, 120);
});
