import { Avatar } from '../components/Avatar';
import { Sheet } from '../components/Sheet';
import { CREATORS } from '../data/seed';
import { useT } from '../i18n';
import { navigate, paths } from '../lib/router';
import { useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function NewChatSheet() {
  const t = useT();
  const { state } = useStore();
  const { closeSheet } = useUi();
  const people = CREATORS.filter((c) => !state.blocked.includes(c.id));

  return (
    <Sheet title={t('msg.newTitle')} onClose={() => closeSheet()}>
      <ul className="menu">
        {people.map((c) => (
          <li key={c.id}>
            <button type="button" className="menu__item" onClick={() => closeSheet(() => navigate(paths.thread(c.id)))}>
              <Avatar name={c.name} hue={c.hue} size={40} />
              <span className="menu__text">
                <strong>{c.name}</strong>
                <small>@{c.handle}</small>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}
