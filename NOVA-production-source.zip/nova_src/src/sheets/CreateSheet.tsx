import { useRef, useState } from 'react';
import { ImagePlus, Trash2 } from 'lucide-react';
import { Sheet } from '../components/Sheet';
import { LIMITS } from '../config';
import { useT } from '../i18n';
import { uid } from '../lib/format';
import { processImage, validateImage } from '../lib/image';
import { navigate, paths } from '../lib/router';
import { useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function CreateSheet() {
  const t = useT();
  const { dispatch } = useStore();
  const { closeSheet, toast } = useUi();
  const fileRef = useRef<HTMLInputElement>(null);
  const [caption, setCaption] = useState('');
  const [image, setImage] = useState<{ dataUrl: string; ratio: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const pick = async (file: File | undefined) => {
    if (!file) return;
    setError('');
    const problem = validateImage(file);
    if (problem === 'type') return setError(t('create.errType'));
    if (problem === 'size') return setError(t('create.errSize', { n: LIMITS.imageMaxMB }));
    setBusy(true);
    try {
      setImage(await processImage(file));
    } catch {
      setError(t('create.errRead'));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const canPublish = !busy && (caption.trim().length > 0 || image !== null);

  const publish = () => {
    if (!canPublish) return;
    dispatch({
      type: 'addPost',
      post: {
        id: 'u' + uid(),
        authorId: 'me',
        image: image?.dataUrl ?? '',
        ratio: image?.ratio ?? 1,
        caption: caption.trim(),
        tags: [],
        category: 'photo',
        createdAt: Date.now(),
        likes: 0,
        commentCount: 0,
        comments: [],
      },
    });
    toast(t('create.posted'));
    closeSheet(() => navigate(paths.home));
  };

  return (
    <Sheet title={t('create.title')} onClose={() => closeSheet()} tall>
      <div className="form">
        <input
          ref={fileRef}
          className="sr-only"
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          onChange={(e) => void pick(e.target.files?.[0])}
          tabIndex={-1}
          aria-hidden="true"
        />

        {image ? (
          <div className="upload upload--filled">
            <img src={image.dataUrl} alt="" />
            <div className="upload__actions">
              <button type="button" className="btn btn--glass" onClick={() => fileRef.current?.click()}>
                {t('create.changePhoto')}
              </button>
              <button type="button" className="btn btn--glass" onClick={() => setImage(null)} aria-label={t('create.removePhoto')}>
                <Trash2 size={16} aria-hidden="true" />
              </button>
            </div>
          </div>
        ) : (
          <button type="button" className="upload" onClick={() => fileRef.current?.click()} disabled={busy}>
            <ImagePlus size={32} aria-hidden="true" />
            <strong>{busy ? t('create.processing') : t('create.addPhoto')}</strong>
            <small>{t('create.pickHint', { n: LIMITS.imageMaxMB })}</small>
          </button>
        )}

        {error && (
          <p className="form__error" role="alert">
            {error}
          </p>
        )}

        <label className="field">
          <span className="field__label">{t('create.captionLabel')}</span>
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder={t('create.captionPh')}
            maxLength={LIMITS.caption}
            rows={4}
          />
          <span className="field__count">
            {caption.length}/{LIMITS.caption}
          </span>
        </label>

        <p className="form__hint">{t('create.privacy')}</p>

        <button type="button" className="btn btn--primary btn--block" disabled={!canPublish} onClick={publish}>
          {t('create.publish')}
        </button>
      </div>
    </Sheet>
  );
}
