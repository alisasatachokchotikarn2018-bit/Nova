import { useState } from 'react';
import { Send } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { Sheet } from '../components/Sheet';
import { LIMITS } from '../config';
import { useLang, useT } from '../i18n';
import { timeAgo } from '../lib/format';
import { findPost, resolveAuthor, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function CommentsSheet({ postId }: { postId: string }) {
  const t = useT();
  const lang = useLang();
  const { state, dispatch } = useStore();
  const { closeSheet } = useUi();
  const [draft, setDraft] = useState('');
  const post = findPost(postId, state.myPosts);
  const comments = [...(post?.comments ?? []), ...(state.comments[postId] ?? [])];

  const submit = () => {
    const text = draft.trim();
    if (!text) return;
    dispatch({ type: 'addComment', postId, text });
    setDraft('');
  };

  return (
    <Sheet
      title={t('comments.title')}
      onClose={() => closeSheet()}
      tall
      footer={
        <form
          className="composer composer--sheet"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={t('comments.placeholder')}
            aria-label={t('comments.placeholder')}
            maxLength={LIMITS.comment}
            enterKeyHint="send"
          />
          <button type="submit" className="send-btn" disabled={!draft.trim()} aria-label={t('comments.post')}>
            <Send size={18} aria-hidden="true" />
          </button>
        </form>
      }
    >
      {comments.length === 0 ? (
        <p className="muted center pad">{t('comments.empty')}</p>
      ) : (
        <ul className="comments">
          {comments.map((c) => {
            const a = resolveAuthor(c.authorId, state.profile);
            return (
              <li key={c.id}>
                <Avatar name={a.name} hue={a.hue} src={a.avatar} size={34} />
                <div>
                  <p>
                    <strong>{a.name}</strong> {c.text}
                  </p>
                  <small>{timeAgo(c.at, lang)}</small>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </Sheet>
  );
}
