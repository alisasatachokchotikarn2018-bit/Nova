import { useRef, useState } from 'react';
import { ChevronRight, Download, FileText, Shield, Trash2, Upload } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { Segmented } from '../components/Common';
import { Sheet } from '../components/Sheet';
import { APP_VERSION, CONTACT_EMAIL, LIMITS } from '../config';
import { useLang, useT } from '../i18n';
import { LEGAL, type LegalKind } from '../i18n/legal';
import { exportBackup, readBackup } from '../lib/backup';
import { processImage, validateImage } from '../lib/image';
import { useStore } from '../store/AppStore';
import { restoreState } from '../store/migrate';
import { useUi } from '../ui/UiContext';
import type { Lang, ThemePref } from '../types';

const HANDLE_RE = /^[a-z0-9._]+$/;

export function EditProfileSheet() {
  const t = useT();
  const { state, dispatch } = useStore();
  const { closeSheet, toast } = useUi();
  const fileRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState(state.profile.name);
  const [handle, setHandle] = useState(state.profile.handle);
  const [bio, setBio] = useState(state.profile.bio);
  const [avatar, setAvatar] = useState(state.profile.avatar);
  const [errors, setErrors] = useState<{ name?: string; handle?: string; avatar?: string }>({});

  const pickAvatar = async (file: File | undefined) => {
    if (!file) return;
    const problem = validateImage(file);
    if (problem === 'type') return setErrors((e) => ({ ...e, avatar: t('create.errType') }));
    if (problem === 'size') return setErrors((e) => ({ ...e, avatar: t('create.errSize', { n: LIMITS.imageMaxMB }) }));
    try {
      const out = await processImage(file, { maxPx: LIMITS.avatarPx, square: true, quality: 0.85 });
      setAvatar(out.dataUrl);
      setErrors((e) => ({ ...e, avatar: undefined }));
    } catch {
      setErrors((e) => ({ ...e, avatar: t('create.errRead') }));
    } finally {
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const save = () => {
    const cleanName = name.trim();
    const cleanHandle = handle.trim().toLowerCase();
    const next: typeof errors = {};
    if (!cleanName) next.name = t('edit.errName');
    if (cleanHandle.length < LIMITS.handleMin || cleanHandle.length > LIMITS.handleMax || !HANDLE_RE.test(cleanHandle)) {
      next.handle = t('edit.errHandle', { min: LIMITS.handleMin, max: LIMITS.handleMax });
    }
    setErrors(next);
    if (next.name || next.handle) return;
    dispatch({ type: 'setProfile', profile: { name: cleanName, handle: cleanHandle, bio: bio.trim(), avatar } });
    toast(t('edit.saved'));
    closeSheet();
  };

  return (
    <Sheet title={t('edit.title')} onClose={() => closeSheet()} tall>
      <div className="form">
        <div className="avatar-edit">
          <Avatar name={name || '?'} src={avatar || undefined} size={88} />
          <input
            ref={fileRef}
            className="sr-only"
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={(e) => void pickAvatar(e.target.files?.[0])}
            tabIndex={-1}
            aria-hidden="true"
          />
          <div className="avatar-edit__actions">
            <button type="button" className="btn btn--soft" onClick={() => fileRef.current?.click()}>
              {t('edit.avatar')}
            </button>
            {avatar && (
              <button type="button" className="link-btn" onClick={() => setAvatar('')}>
                {t('edit.removeAvatar')}
              </button>
            )}
          </div>
        </div>
        {errors.avatar && (
          <p className="form__error" role="alert">
            {errors.avatar}
          </p>
        )}

        <label className="field">
          <span className="field__label">{t('edit.name')}</span>
          <input value={name} onChange={(e) => setName(e.target.value)} maxLength={LIMITS.name} autoComplete="name" aria-invalid={!!errors.name} />
          {errors.name && (
            <span className="form__error" role="alert">
              {errors.name}
            </span>
          )}
        </label>

        <label className="field">
          <span className="field__label">{t('edit.handle')}</span>
          <input
            value={handle}
            onChange={(e) => setHandle(e.target.value.toLowerCase())}
            maxLength={LIMITS.handleMax}
            autoCapitalize="none"
            autoCorrect="off"
            spellCheck={false}
            aria-invalid={!!errors.handle}
          />
          {errors.handle && (
            <span className="form__error" role="alert">
              {errors.handle}
            </span>
          )}
        </label>

        <label className="field">
          <span className="field__label">{t('edit.bio')}</span>
          <textarea value={bio} onChange={(e) => setBio(e.target.value)} maxLength={LIMITS.bio} rows={3} />
          <span className="field__count">
            {bio.length}/{LIMITS.bio}
          </span>
        </label>

        <button type="button" className="btn btn--primary btn--block" onClick={save}>
          {t('common.save')}
        </button>
      </div>
    </Sheet>
  );
}

export function SettingsSheet() {
  const t = useT();
  const { state, dispatch } = useStore();
  const { openSheet, closeSheet, toast } = useUi();
  const importRef = useRef<HTMLInputElement>(null);

  const doExport = async () => {
    const result = await exportBackup(state);
    if (result === 'failed') toast(t('settings.exportFailed'));
    else if (result !== 'cancelled') toast(t('settings.exported'));
  };

  const doImport = async (file: File | undefined) => {
    if (!file) return;
    try {
      const raw = await readBackup(file);
      dispatch({ type: 'restore', state: restoreState(raw, state) });
      toast(t('settings.imported'));
    } catch {
      toast(t('settings.importFailed'));
    } finally {
      if (importRef.current) importRef.current.value = '';
    }
  };

  return (
    <Sheet title={t('settings.title')} onClose={() => closeSheet()} tall>
      <div className="settings">
        <section>
          <h3>{t('settings.language')}</h3>
          <Segmented<Lang>
            label={t('settings.language')}
            value={state.lang}
            options={[
              { value: 'th', label: 'ไทย' },
              { value: 'en', label: 'English' },
            ]}
            onChange={(v) => dispatch({ type: 'setLang', lang: v })}
          />
        </section>

        <section>
          <h3>{t('settings.theme')}</h3>
          <Segmented<ThemePref>
            label={t('settings.theme')}
            value={state.theme}
            options={[
              { value: 'system', label: t('settings.themeSystem') },
              { value: 'light', label: t('settings.themeLight') },
              { value: 'dark', label: t('settings.themeDark') },
            ]}
            onChange={(v) => dispatch({ type: 'setTheme', theme: v })}
          />
        </section>

        <section>
          <h3>{t('settings.legal')}</h3>
          <ul className="menu">
            <li>
              <button type="button" className="menu__item" onClick={() => openSheet({ kind: 'legal', doc: 'privacy' })}>
                <Shield size={20} aria-hidden="true" />
                {t('settings.privacy')}
                <ChevronRight className="menu__chev" size={18} aria-hidden="true" />
              </button>
            </li>
            <li>
              <button type="button" className="menu__item" onClick={() => openSheet({ kind: 'legal', doc: 'terms' })}>
                <FileText size={20} aria-hidden="true" />
                {t('settings.terms')}
                <ChevronRight className="menu__chev" size={18} aria-hidden="true" />
              </button>
            </li>
          </ul>
        </section>

        <section>
          <h3>{t('settings.data')}</h3>
          <input
            ref={importRef}
            className="sr-only"
            type="file"
            accept="application/json,.json"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(e) => void doImport(e.target.files?.[0])}
          />
          <ul className="menu">
            <li>
              <button type="button" className="menu__item" onClick={() => void doExport()}>
                <Download size={20} aria-hidden="true" />
                {t('settings.export')}
              </button>
            </li>
            <li>
              <button type="button" className="menu__item" onClick={() => importRef.current?.click()}>
                <Upload size={20} aria-hidden="true" />
                {t('settings.import')}
              </button>
            </li>
            <li>
              <button type="button" className="menu__item menu__item--danger" onClick={() => openSheet({ kind: 'confirm', action: 'resetAll' })}>
                <Trash2 size={20} aria-hidden="true" />
                {t('settings.reset')}
              </button>
            </li>
          </ul>
          <p className="muted hint">{t('settings.backupHint')}</p>
        </section>

        <section className="about">
          <h3>{t('settings.about')}</h3>
          <p className="muted">{t('settings.version', { v: APP_VERSION })}</p>
          {CONTACT_EMAIL && (
            <p>
              <a href={`mailto:${CONTACT_EMAIL}`}>
                {t('settings.contact')}: {CONTACT_EMAIL}
              </a>
            </p>
          )}
        </section>
      </div>
    </Sheet>
  );
}

export function LegalSheet({ doc }: { doc: LegalKind }) {
  const lang = useLang();
  const { closeSheet } = useUi();
  const content = LEGAL[doc][lang];

  return (
    <Sheet title={content.title} onClose={() => closeSheet()} tall>
      <article className="legal">
        <p className="muted">{content.updated}</p>
        {content.sections.map((s) => (
          <section key={s.h}>
            <h3>{s.h}</h3>
            <p>{s.p}</p>
          </section>
        ))}
      </article>
    </Sheet>
  );
}
