import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { SafeImage } from '../components/SafeImage';
import { CREATOR_MAP, sized } from '../data/seed';
import { useT } from '../i18n';
import { useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

const SLIDE_MS = 5000;

export function StoryViewer({ creatorId }: { creatorId: string }) {
  const t = useT();
  const { dispatch } = useStore();
  const { closeSheet } = useUi();
  const creator = CREATOR_MAP[creatorId];
  const slides = creator?.stories ?? [];
  const [index, setIndex] = useState(0);

  useEffect(() => {
    dispatch({ type: 'seeStory', id: creatorId });
  }, [creatorId, dispatch]);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) return;
    const id = window.setTimeout(() => {
      if (index >= slides.length - 1) closeSheet();
      else setIndex(index + 1);
    }, SLIDE_MS);
    return () => window.clearTimeout(id);
  }, [index, slides.length, closeSheet]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeSheet();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [closeSheet]);

  if (!creator || slides.length === 0) return null;

  const next = () => (index >= slides.length - 1 ? closeSheet() : setIndex(index + 1));
  const prev = () => setIndex(Math.max(0, index - 1));

  return (
    <div className="story-view" role="dialog" aria-modal="true" aria-label={t('story.of', { name: creator.name })}>
      <SafeImage className="story-view__img" src={sized(`https://images.unsplash.com/photo-${slides[index]}`, 1080)} alt="" eager />
      <div className="story-view__scrim" aria-hidden="true" />

      <div className="story-view__bars" aria-hidden="true">
        {slides.map((_, i) => (
          <span key={i} className={i < index ? 'is-done' : i === index ? 'is-active' : ''}>
            <i />
          </span>
        ))}
      </div>

      <header className="story-view__head">
        <Avatar name={creator.name} hue={creator.hue} size={36} />
        <strong>{creator.name}</strong>
        <button type="button" className="icon-btn icon-btn--glass" onClick={() => closeSheet()} aria-label={t('common.close')} autoFocus>
          <X aria-hidden="true" />
        </button>
      </header>

      <button type="button" className="story-view__tap story-view__tap--prev" onClick={prev} aria-label={t('story.prev')} />
      <button type="button" className="story-view__tap story-view__tap--next" onClick={next} aria-label={t('story.next')} />
    </div>
  );
}
