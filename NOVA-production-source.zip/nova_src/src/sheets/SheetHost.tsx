import { useUi } from '../ui/UiContext';
import { CommentsSheet } from './CommentsSheet';
import { CreateSheet } from './CreateSheet';
import { NewChatSheet } from './NewChatSheet';
import { ConfirmSheet, PostMenuSheet, PostSheet, ReportSheet } from './PostSheets';
import { EditProfileSheet, LegalSheet, SettingsSheet } from './ProfileSheets';
import { StoryViewer } from './StoryViewer';

export function SheetHost() {
  const { sheet } = useUi();
  if (!sheet) return null;

  switch (sheet.kind) {
    case 'create':
      return <CreateSheet />;
    case 'comments':
      return <CommentsSheet postId={sheet.postId} />;
    case 'postMenu':
      return <PostMenuSheet postId={sheet.postId} />;
    case 'post':
      return <PostSheet postId={sheet.postId} />;
    case 'report':
      return <ReportSheet postId={sheet.postId} />;
    case 'confirm':
      return sheet.action === 'deletePost' ? (
        <ConfirmSheet action="deletePost" postId={sheet.postId} />
      ) : (
        <ConfirmSheet action="resetAll" />
      );
    case 'editProfile':
      return <EditProfileSheet />;
    case 'settings':
      return <SettingsSheet />;
    case 'legal':
      return <LegalSheet doc={sheet.doc} />;
    case 'newChat':
      return <NewChatSheet />;
    case 'story':
      return <StoryViewer creatorId={sheet.creatorId} />;
  }
}
