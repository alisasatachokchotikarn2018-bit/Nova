import { Ban, ChevronRight, EyeOff, Flag, Trash2 } from 'lucide-react';
import { PostCard } from '../components/PostCard';
import { Sheet } from '../components/Sheet';
import { useT } from '../i18n';
import type { Key } from '../i18n/th';
import { findPost, resolveAuthor, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function PostSheet({ postId }: { postId: string }) {
  const t = useT();
  const { state } = useStore();
  const { closeSheet } = useUi();
  const post = findPost(postId, state.myPosts);
  const author = post ? resolveAuthor(post.authorId, state.profile) : null;

  return (
    <Sheet title={author?.name ?? t('profile.openPost')} onClose={() => closeSheet()} tall hideTitle>
      {post ? <PostCard post={post} priority /> : null}
    </Sheet>
  );
}

export function PostMenuSheet({ postId }: { postId: string }) {
  const t = useT();
  const { state, dispatch } = useStore();
  const { openSheet, closeSheet, toast } = useUi();
  const post = findPost(postId, state.myPosts);
  if (!post) return null;
  const author = resolveAuthor(post.authorId, state.profile);
  const mine = post.authorId === 'me';

  return (
    <Sheet title={t('post.options')} onClose={() => closeSheet()} hideTitle>
      <ul className="menu">
        {mine ? (
          <li>
            <button type="button" className="menu__item menu__item--danger" onClick={() => openSheet({ kind: 'confirm', action: 'deletePost', postId })}>
              <Trash2 size={20} aria-hidden="true" />
              {t('menu.delete')}
            </button>
          </li>
        ) : (
          <>
            <li>
              <button type="button" className="menu__item menu__item--danger" onClick={() => openSheet({ kind: 'report', postId })}>
                <Flag size={20} aria-hidden="true" />
                {t('menu.report')}
              </button>
            </li>
            <li>
              <button
                type="button"
                className="menu__item"
                onClick={() => {
                  dispatch({ type: 'hidePost', id: postId });
                  toast(t('menu.hidden'));
                  closeSheet();
                }}
              >
                <EyeOff size={20} aria-hidden="true" />
                {t('menu.hide')}
              </button>
            </li>
            <li>
              <button
                type="button"
                className="menu__item menu__item--danger"
                onClick={() => {
                  dispatch({ type: 'blockUser', id: post.authorId });
                  toast(t('menu.blocked', { name: author.name }));
                  closeSheet();
                }}
              >
                <Ban size={20} aria-hidden="true" />
                {t('menu.block', { name: author.name })}
              </button>
            </li>
          </>
        )}
      </ul>
    </Sheet>
  );
}

const REASONS = ['spam', 'inappropriate', 'harassment', 'misinfo', 'copyright', 'other'] as const;

export function ReportSheet({ postId }: { postId: string }) {
  const t = useT();
  const { dispatch } = useStore();
  const { closeSheet, toast } = useUi();

  return (
    <Sheet title={t('report.title')} onClose={() => closeSheet()}>
      <p className="muted pad-x">{t('report.subtitle')}</p>
      <ul className="menu">
        {REASONS.map((reason) => (
          <li key={reason}>
            <button
              type="button"
              className="menu__item"
              onClick={() => {
                dispatch({ type: 'report', postId, reason });
                toast(t('report.thanks'));
                closeSheet();
              }}
            >
              {t(`report.${reason}` as Key)}
              <ChevronRight className="menu__chev" size={18} aria-hidden="true" />
            </button>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

export function ConfirmSheet({ action, postId }: { action: 'deletePost' | 'resetAll'; postId?: string }) {
  const t = useT();
  const { dispatch, resetAll } = useStore();
  const { closeSheet, toast } = useUi();
  const isReset = action === 'resetAll';

  const confirm = () => {
    if (isReset) {
      resetAll();
      return;
    }
    if (postId) dispatch({ type: 'deletePost', id: postId });
    toast(t('menu.deleted'));
    closeSheet();
  };

  return (
    <Sheet title={isReset ? t('settings.resetTitle') : t('menu.deleteTitle')} onClose={() => closeSheet()}>
      <p className="muted pad-x">{isReset ? t('settings.resetBody') : t('menu.deleteBody')}</p>
      <div className="stack">
        <button type="button" className="btn btn--danger btn--block" onClick={confirm}>
          {isReset ? t('settings.resetBtn') : t('common.delete')}
        </button>
        <button type="button" className="btn btn--soft btn--block" onClick={() => closeSheet()}>
          {t('common.cancel')}
        </button>
      </div>
    </Sheet>
  );
}
