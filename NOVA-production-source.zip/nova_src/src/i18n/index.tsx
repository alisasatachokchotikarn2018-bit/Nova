import { createContext, useCallback, useContext, useEffect, useMemo, type ReactNode } from 'react';
import type { Lang } from '../types';
import { useStore } from '../store/AppStore';
import { th, type Key } from './th';
import { en } from './en';

const dictionaries: Record<Lang, Record<Key, string>> = { th, en };

export type TFn = (key: Key, vars?: Record<string, string | number>) => string;

interface I18nValue {
  lang: Lang;
  t: TFn;
}

const I18nContext = createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const {
    state: { lang },
  } = useStore();

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const t = useCallback<TFn>(
    (key, vars) => {
      let text = dictionaries[lang][key] ?? key;
      if (vars) {
        for (const [k, v] of Object.entries(vars)) text = text.split(`{${k}}`).join(String(v));
      }
      return text;
    },
    [lang],
  );

  const value = useMemo(() => ({ lang, t }), [lang, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
}

export const useT = (): TFn => useI18n().t;
export const useLang = (): Lang => useI18n().lang;
