import type { Lang } from '../types';

export interface LegalDoc {
  title: string;
  updated: string;
  sections: { h: string; p: string }[];
}

export type LegalKind = 'privacy' | 'terms';

export const LEGAL: Record<LegalKind, Record<Lang, LegalDoc>> = {
  privacy: {
    th: {
      title: 'นโยบายความเป็นส่วนตัว',
      updated: 'ปรับปรุงล่าสุด: ม.ค. 2027',
      sections: [
        {
          h: 'ข้อมูลที่เราเก็บ',
          p: 'เวอร์ชันนี้เก็บโปรไฟล์ โพสต์ ความคิดเห็น ข้อความ และการตั้งค่าของคุณไว้ในอุปกรณ์ของคุณเท่านั้น (ที่เก็บข้อมูลของเบราว์เซอร์) และยังไม่ส่งข้อมูลเหล่านี้ไปยังเซิร์ฟเวอร์ของ NOVA',
        },
        {
          h: 'รูปภาพที่คุณอัปโหลด',
          p: 'รูปจะถูกย่อขนาดและลบข้อมูลที่ฝังในไฟล์ เช่น ตำแหน่ง GPS ก่อนบันทึก',
        },
        {
          h: 'บริการภายนอก',
          p: 'รูปตัวอย่างบางส่วนในแอปโหลดจากบริการภายนอก (Unsplash) ซึ่งอาจเห็นที่อยู่ IP ของคุณตามปกติของการเปิดเว็บ',
        },
        {
          h: 'สิทธิ์ของคุณ',
          p: 'คุณขอดู แก้ไข หรือลบข้อมูลของคุณได้ตลอดเวลา แก้ไขได้ที่หน้าโปรไฟล์ และลบข้อมูลทั้งหมดได้ที่ การตั้งค่า > ลบข้อมูลทั้งหมดในอุปกรณ์นี้ ตามสิทธิ์ภายใต้พระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล (PDPA)',
        },
        {
          h: 'ผู้เยาว์',
          p: 'ผู้ใช้ควรมีอายุอย่างน้อย 13 ปี ผู้เยาว์ควรได้รับความยินยอมจากผู้ปกครองก่อนใช้งาน',
        },
        {
          h: 'การเปลี่ยนแปลงนโยบาย',
          p: 'หากมีการเปลี่ยนแปลงวิธีเก็บข้อมูล เราจะปรับปรุงนโยบายนี้และแจ้งให้ทราบก่อนเริ่มใช้',
        },
      ],
    },
    en: {
      title: 'Privacy policy',
      updated: 'Last updated: Jan 2027',
      sections: [
        {
          h: 'What we store',
          p: 'This version keeps your profile, posts, comments, messages and settings on your own device only (browser storage). It does not send this data to NOVA servers.',
        },
        {
          h: 'Photos you upload',
          p: 'Photos are resized and stripped of embedded metadata, such as GPS location, before they are saved.',
        },
        {
          h: 'Third-party services',
          p: 'Some sample images in the app load from an external service (Unsplash), which can see your IP address as with any web page.',
        },
        {
          h: 'Your rights',
          p: 'You can view, edit or delete your data at any time. Edit it on the Profile page, or delete everything under Settings > Delete all data on this device, in line with your rights under data protection law (such as Thailand’s PDPA).',
        },
        {
          h: 'Minors',
          p: 'You should be at least 13 years old to use NOVA. Minors should have a parent or guardian’s consent.',
        },
        {
          h: 'Changes to this policy',
          p: 'If the way we handle data changes, we will update this policy and let you know before the change takes effect.',
        },
      ],
    },
  },
  terms: {
    th: {
      title: 'ข้อกำหนดการใช้งาน',
      updated: 'ปรับปรุงล่าสุด: ม.ค. 2027',
      sections: [
        {
          h: 'การใช้งาน',
          p: 'การใช้ NOVA หมายความว่าคุณยอมรับข้อกำหนดเหล่านี้ กรุณาใช้งานอย่างสุภาพและเคารพผู้อื่น',
        },
        {
          h: 'เนื้อหาของคุณ',
          p: 'คุณเป็นเจ้าของเนื้อหาที่โพสต์ และรับรองว่ามีสิทธิ์ใช้รูปและข้อความนั้น ห้ามโพสต์เนื้อหาที่ละเมิดลิขสิทธิ์ ผิดกฎหมาย อนาจาร หรือคุกคามผู้อื่น',
        },
        {
          h: 'การรายงานและการบล็อก',
          p: 'คุณรายงานโพสต์ ซ่อนโพสต์ หรือบล็อกผู้ใช้ได้จากเมนู ⋯ บนโพสต์ เนื้อหาที่ฝ่าฝืนข้อกำหนดอาจถูกนำออก',
        },
        {
          h: 'NOVA AI',
          p: 'NOVA AI อยู่ในช่วงทดลองและอาจให้ข้อมูลไม่ถูกต้อง โปรดอย่าใช้แทนคำแนะนำทางการแพทย์ กฎหมาย หรือการเงิน',
        },
        {
          h: 'การเปลี่ยนแปลงบริการ',
          p: 'เราอาจปรับปรุง เปลี่ยนแปลง หรือหยุดให้บริการบางส่วนได้ และจะแจ้งให้ทราบเมื่อมีการเปลี่ยนแปลงสำคัญ',
        },
      ],
    },
    en: {
      title: 'Terms of use',
      updated: 'Last updated: Jan 2027',
      sections: [
        {
          h: 'Using NOVA',
          p: 'By using NOVA you agree to these terms. Please be kind and respectful to others.',
        },
        {
          h: 'Your content',
          p: 'You own what you post and confirm you have the right to use those photos and words. Do not post content that infringes copyright, is illegal, obscene or harasses others.',
        },
        {
          h: 'Reporting and blocking',
          p: 'You can report a post, hide it or block a user from the ⋯ menu on any post. Content that breaks these terms may be removed.',
        },
        {
          h: 'NOVA AI',
          p: 'NOVA AI is in trial and may be inaccurate. Do not rely on it for medical, legal or financial advice.',
        },
        {
          h: 'Changes to the service',
          p: 'We may improve, change or stop parts of the service, and will let you know about significant changes.',
        },
      ],
    },
  },
};
