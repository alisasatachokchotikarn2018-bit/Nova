import { AI_ENDPOINT } from '../config';
import type { Lang } from '../types';

const delay = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const id = window.setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      window.clearTimeout(id);
      reject(new DOMException('Aborted', 'AbortError'));
    });
  });

const REPLIES: Record<Lang, { caption: string; ideas: string; summary: string; fallback: string; note: string }> = {
  th: {
    caption:
      'ลองแคปชันเหล่านี้ดูนะ\n1. “ช่วงเวลาเล็ก ๆ ที่ทำให้วันนี้พิเศษ ✨”\n2. “เก็บแสงสุดท้ายของวันไว้ในรูปนี้”\n3. “ไปไหนก็ได้ ขอแค่ได้ไปด้วยกัน 💙”',
    ideas:
      'ไอเดียโพสต์สำหรับวันนี้\n• ภาพก่อน–หลังของมุมโปรดในบ้าน\n• 3 สิ่งเล็ก ๆ ที่ทำให้คุณยิ้มวันนี้\n• เบื้องหลังการถ่ายภาพที่คุณภูมิใจที่สุด',
    summary: 'วางข้อความที่ต้องการสรุปมาได้เลย เราจะช่วยย่อให้เหลือประเด็นสำคัญ',
    fallback: 'ได้เลย! บอกเป้าหมายหรือรายละเอียดเพิ่มอีกนิด เราจะช่วยคิดให้',
    note: '\n\n(โหมดทดลอง: คำตอบจากตัวอย่างในแอป)',
  },
  en: {
    caption:
      'Try one of these captions:\n1. “Small moments that made today special ✨”\n2. “Keeping the last light of the day in this frame”\n3. “Anywhere is fine, as long as we go together 💙”',
    ideas:
      'Post ideas for today:\n• A before-and-after of your favorite corner at home\n• 3 small things that made you smile today\n• Behind the scenes of the photo you’re proudest of',
    summary: 'Paste the text you want summarized and we’ll boil it down to the key points.',
    fallback: 'Sure! Tell us a bit more about what you’re after and we’ll help.',
    note: '\n\n(Trial mode: sample replies built into the app)',
  },
};

function localReply(message: string, lang: Lang): string {
  const r = REPLIES[lang];
  const m = message.toLowerCase();
  if (/(caption|แคปชัน)/.test(m)) return r.caption + r.note;
  if (/(idea|ไอเดีย)/.test(m)) return r.ideas + r.note;
  if (/(summar|สรุป)/.test(m)) return r.summary + r.note;
  return r.fallback + r.note;
}

/**
 * Sends a message to NOVA AI. With VITE_NOVA_AI_ENDPOINT set it POSTs
 * { message, lang } and expects { reply: string }; otherwise it returns sample replies.
 */
export async function askNova(message: string, lang: Lang, signal?: AbortSignal): Promise<string> {
  if (AI_ENDPOINT) {
    const res = await fetch(AI_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, lang }),
      signal,
    });
    if (!res.ok) throw new Error(`AI request failed: ${res.status}`);
    const data = (await res.json()) as { reply?: unknown };
    if (typeof data.reply !== 'string' || !data.reply) throw new Error('Empty AI reply');
    return data.reply;
  }
  await delay(700, signal);
  return localReply(message, lang);
}
