export const APP_NAME = 'NOVA';
export const APP_VERSION = '1.0.0';
export const STORAGE_KEY = 'nova:v1';

type Env = Record<string, string | boolean | undefined>;
const env: Env = (import.meta as unknown as { env?: Env }).env ?? {};

export const IS_PROD: boolean = env.PROD === true;

/** Optional: contact address shown in Settings. Leave empty to hide the line. */
export const CONTACT_EMAIL: string = typeof env.VITE_CONTACT_EMAIL === 'string' ? env.VITE_CONTACT_EMAIL : '';

/** Optional: POST endpoint for NOVA AI -> { reply: string }. Empty = built-in sample replies. */
export const AI_ENDPOINT: string = typeof env.VITE_NOVA_AI_ENDPOINT === 'string' ? env.VITE_NOVA_AI_ENDPOINT : '';

export const LIMITS = {
  caption: 500,
  comment: 300,
  message: 1000,
  bio: 120,
  name: 30,
  handleMin: 3,
  handleMax: 20,
  imageMaxMB: 15,
  imageMaxPx: 1080,
  avatarPx: 256,
} as const;
