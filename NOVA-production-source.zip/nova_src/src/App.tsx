import { Component, useEffect, useRef, type ErrorInfo, type ReactNode } from 'react';
import { Toast } from './components/Common';
import { TabBar } from './components/TabBar';
import { I18nProvider, useLang, useT } from './i18n';
import { useRoute } from './lib/router';
import { AiScreen } from './screens/AiScreen';
import { ExploreScreen } from './screens/ExploreScreen';
import { HomeScreen } from './screens/HomeScreen';
import { MessagesScreen, ThreadScreen } from './screens/MessagesScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { ReelsScreen } from './screens/ReelsScreen';
import { SheetHost } from './sheets/SheetHost';
import { AppProvider, useStore } from './store/AppStore';
import { UiProvider, useUi } from './ui/UiContext';

function useTheme() {
  const {
    state: { theme },
  } = useStore();
  useEffect(() => {
    const root = document.documentElement;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const dark = theme === 'dark' || (theme === 'system' && mq.matches);
      root.dataset.theme = dark ? 'dark' : 'light';
      document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0d1726' : '#ffffff');
    };
    apply();
    mq.addEventListener('change', apply);
    return () => mq.removeEventListener('change', apply);
  }, [theme]);
}

function StorageWatcher() {
  const t = useT();
  const { storageFailed } = useStore();
  const { toast } = useUi();
  useEffect(() => {
    if (storageFailed) toast(t('storage.full'));
  }, [storageFailed, toast, t]);
  return null;
}

function Shell() {
  useTheme();
  const route = useRoute();
  const { toastMessage } = useUi();
  const lang = useLang();
  const screenRef = useRef<HTMLElement>(null);

  useEffect(() => {
    screenRef.current?.scrollTo({ top: 0 });
  }, [route.name, route.id]);

  const fullBleed = route.name === 'reels' || route.name === 'ai' || route.name === 'messages' || route.name === 'thread';
  const hideTabs = route.name === 'messages' || route.name === 'thread';

  let screen: ReactNode;
  switch (route.name) {
    case 'reels':
      screen = <ReelsScreen />;
      break;
    case 'explore':
      screen = <ExploreScreen />;
      break;
    case 'ai':
      screen = <AiScreen />;
      break;
    case 'profile':
      screen = <ProfileScreen />;
      break;
    case 'messages':
      screen = <MessagesScreen />;
      break;
    case 'thread':
      screen = <ThreadScreen id={route.id ?? ''} />;
      break;
    default:
      screen = <HomeScreen />;
  }

  return (
    <div className="stage">
      <div className="app" lang={lang}>
        <main ref={screenRef} className={`screen${fullBleed ? ' screen--fill' : ''}`} id="main">
          {screen}
        </main>
        {!hideTabs && <TabBar route={route.name} />}
        <SheetHost />
        <Toast message={toastMessage} />
        <StorageWatcher />
      </div>
    </div>
  );
}

interface BoundaryState {
  failed: boolean;
}

class ErrorBoundary extends Component<{ children: ReactNode }, BoundaryState> {
  state: BoundaryState = { failed: false };

  static getDerivedStateFromError(): BoundaryState {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('NOVA crashed:', error, info.componentStack);
  }

  render() {
    if (!this.state.failed) return this.props.children;
    const th = navigator.language?.toLowerCase().startsWith('th');
    return (
      <div className="crash" role="alert">
        <h1>{th ? 'เกิดข้อผิดพลาดบางอย่าง' : 'Something went wrong'}</h1>
        <p>{th ? 'ขออภัย แอปหยุดทำงานชั่วคราว ลองโหลดใหม่อีกครั้งนะ' : 'Sorry, the app stopped working for a moment. Please try reloading.'}</p>
        <button type="button" className="btn btn--primary" onClick={() => window.location.reload()}>
          {th ? 'โหลดใหม่' : 'Reload'}
        </button>
      </div>
    );
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <I18nProvider>
          <UiProvider>
            <Shell />
          </UiProvider>
        </I18nProvider>
      </AppProvider>
    </ErrorBoundary>
  );
}
