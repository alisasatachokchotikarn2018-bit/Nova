import type { Author, Creator, Message, Post } from '../types';

/**
 * Sample content shown until a real backend is connected.
 * Replace this module with API calls — every screen reads posts/creators through the store.
 */

const UNSPLASH = 'https://images.unsplash.com/photo-';
const img = (id: string) => UNSPLASH + id;

/** Adds responsive size params to remote photos; data URLs pass through untouched. */
export function sized(src: string, width: number): string {
  return src.startsWith('http') ? `${src}?auto=format&fit=crop&w=${width}&q=70` : src;
}

const ago = (minutes: number) => Date.now() - minutes * 60_000;

export const CREATORS: Creator[] = [
  {
    id: 'nova',
    name: 'NOVA',
    handle: 'nova',
    hue: 205,
    verified: true,
    online: true,
    stories: ['1500530855697-b586d89ba3ee', '1506905925346-21bda4d32df4'],
  },
  {
    id: 'maya',
    name: 'Maya Lin',
    handle: 'maya.lin',
    hue: 330,
    online: true,
    stories: ['1519608487953-e999c86e7455', '1470770841072-f978cf4d019e'],
  },
  { id: 'kion', name: 'Kion Chen', handle: 'kion.chen', hue: 150, online: true, stories: ['1518837695005-2083093ee35b'] },
  { id: 'mint', name: 'Mint Suwan', handle: 'mint.suwan', hue: 28, stories: ['1490750967868-88aa4486c946'] },
  {
    id: 'sarah',
    name: 'Sarah Jenkins',
    handle: 'sarah.j',
    hue: 265,
    online: true,
    stories: ['1501785888041-af3ef285b470'],
  },
];

export const CREATOR_MAP: Record<string, Creator> = Object.fromEntries(CREATORS.map((c) => [c.id, c]));

export const UNKNOWN_AUTHOR: Author = { id: 'unknown', name: '—', handle: 'unknown', hue: 210 };

export const SEED_POSTS: Post[] = [
  {
    id: 'p1',
    authorId: 'maya',
    image: img('1519608487953-e999c86e7455'),
    ratio: 4 / 5,
    caption: 'ถนนเงียบหลังเที่ยงคืน แสงนีออนสะท้อนบนพื้นเปียก 💜',
    tags: ['city', 'night'],
    category: 'city',
    createdAt: ago(120),
    likes: 12400,
    commentCount: 328,
    comments: [
      { id: 'c1', authorId: 'kion', text: 'โทนสีสวยมาก ชอบสุด ๆ', at: ago(100) },
      { id: 'c2', authorId: 'sarah', text: 'อยากไปถ่ายบ้างจัง', at: ago(80) },
    ],
  },
  {
    id: 'p2',
    authorId: 'nova',
    image: img('1500530855697-b586d89ba3ee'),
    ratio: 2 / 3,
    caption: 'ถนนที่ทอดยาวไปสุดขอบฟ้า ออกเดินทางด้วยกันไหม? ✨',
    tags: ['travel', 'NOVA'],
    category: 'travel',
    createdAt: ago(240),
    likes: 245700,
    commentCount: 3786,
    comments: [{ id: 'c3', authorId: 'maya', text: 'พร้อมเลย!', at: ago(200) }],
  },
  {
    id: 'p3',
    authorId: 'kion',
    image: img('1518837695005-2083093ee35b'),
    ratio: 1,
    caption: 'คลื่นเล็ก ๆ ที่ช่วยให้ใจสงบลง',
    tags: ['nature', 'ocean'],
    category: 'nature',
    createdAt: ago(360),
    likes: 8900,
    commentCount: 112,
    comments: [],
  },
  {
    id: 'p4',
    authorId: 'mint',
    image: img('1490750967868-88aa4486c946'),
    ratio: 3 / 4,
    caption: 'ดอกไม้สีเหลืองต้อนรับวันใหม่ 🌼',
    tags: ['nature', 'flowers'],
    category: 'nature',
    createdAt: ago(500),
    likes: 24900,
    commentCount: 540,
    comments: [{ id: 'c4', authorId: 'sarah', text: 'สีสดมาก', at: ago(450) }],
  },
  {
    id: 'p5',
    authorId: 'sarah',
    image: img('1501785888041-af3ef285b470'),
    ratio: 4 / 5,
    caption: 'กลับบ้านทางไกลบ้าง ก็ได้เจอวิวสวย ๆ',
    tags: ['travel', 'mountain'],
    category: 'travel',
    createdAt: ago(900),
    likes: 48200,
    commentCount: 790,
    comments: [],
  },
  {
    id: 'p6',
    authorId: 'maya',
    image: img('1470770841072-f978cf4d019e'),
    ratio: 1,
    caption: 'มีที่ให้หายใจ ก็เพียงพอแล้ว',
    tags: ['nature', 'lake'],
    category: 'nature',
    createdAt: ago(1300),
    likes: 31600,
    commentCount: 260,
    comments: [],
  },
  {
    id: 'p7',
    authorId: 'kion',
    image: img('1506905925346-21bda4d32df4'),
    ratio: 2 / 3,
    caption: 'ยอดเขาเหนือเมฆ',
    tags: ['travel', 'mountain'],
    category: 'photo',
    createdAt: ago(2000),
    likes: 105000,
    commentCount: 1400,
    comments: [],
  },
  {
    id: 'p8',
    authorId: 'mint',
    image: img('1441974231531-c6227db76b6e'),
    ratio: 3 / 4,
    caption: 'แสงแรกในป่า',
    tags: ['nature', 'forest'],
    category: 'photo',
    createdAt: ago(2600),
    likes: 18700,
    commentCount: 201,
    comments: [],
  },
  {
    id: 'p9',
    authorId: 'sarah',
    image: img('1507525428034-b723cf961d3e'),
    ratio: 1,
    caption: 'วันหยุดแบบช้า ๆ ริมทะเล',
    tags: ['travel', 'beach'],
    category: 'travel',
    createdAt: ago(3200),
    likes: 72100,
    commentCount: 640,
    comments: [],
  },
];

export function seedThreads(): Record<string, Message[]> {
  return {
    sarah: [
      { id: 's1', from: 'them', text: 'สวัสดี! เป็นไงบ้าง?', at: ago(95) },
      { id: 's2', from: 'me', text: 'สบายดี เพิ่งกลับจากเที่ยว', at: ago(90) },
      { id: 's3', from: 'them', text: 'เพิ่งส่งรูปให้ดู 💙', at: ago(20) },
    ],
    kion: [
      { id: 'k1', from: 'me', text: 'พรุ่งนี้ว่างไหม', at: ago(1500) },
      { id: 'k2', from: 'them', text: 'ว่างตอนบ่ายนะ ฟังดูดีเลย ✨', at: ago(1450) },
    ],
    maya: [{ id: 'm1', from: 'them', text: 'ดูรูปนี้สิ 📷', at: ago(3000) }],
  };
}

export function seedUnread(): Record<string, number> {
  return { sarah: 1 };
}
