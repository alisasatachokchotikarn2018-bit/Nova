import { useState } from 'react';
import { BadgeCheck, Bookmark, Heart, MessageCircle, MoreHorizontal, Send } from 'lucide-react';
import { sized } from '../data/seed';
import { useLang, useT } from '../i18n';
import { compact, timeAgo } from '../lib/format';
import { shareLink } from '../lib/share';
import { resolveAuthor, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';
import type { Post } from '../types';
import { Avatar } from './Avatar';
import { SafeImage } from './SafeImage';

export function usePostActions(post: Post) {
  const { state, dispatch } = useStore();
  const { toast } = useUi();
  const t = useT();
  const author = resolveAuthor(post.authorId, state.profile);
  const liked = state.liked.includes(post.id);
  const saved = state.saved.includes(post.id);
  const commentTotal = post.commentCount + (state.comments[post.id]?.length ?? 0);
  const likeTotal = post.likes + (liked ? 1 : 0);

  const share = async () => {
    const result = await shareLink(t('post.shareText', { name: author.name }));
    if (result === 'copied') toast(t('post.copied'));
    if (result === 'failed') toast(t('post.shareFailed'));
  };

  return {
    author,
    liked,
    saved,
    commentTotal,
    likeTotal,
    toggleLike: () => dispatch({ type: 'toggleLike', id: post.id }),
    toggleSave: () => dispatch({ type: 'toggleSave', id: post.id }),
    share,
  };
}

export function PostCard({ post, priority = false }: { post: Post; priority?: boolean }) {
  const t = useT();
  const lang = useLang();
  const { openSheet } = useUi();
  const { author, liked, saved, commentTotal, likeTotal, toggleLike, toggleSave, share } = usePostActions(post);
  const [expanded, setExpanded] = useState(false);
  const [burst, setBurst] = useState(0);
  const longCaption = post.caption.length > 90;

  const doubleTapLike = () => {
    if (!liked) toggleLike();
    setBurst((n) => n + 1);
  };

  return (
    <article className="post">
      <header className="post__head">
        <Avatar name={author.name} hue={author.hue} src={author.avatar} size={38} />
        <div className="post__who">
          <strong>
            {author.name}
            {author.verified && <BadgeCheck className="verified" size={15} aria-label={t('common.verified')} />}
          </strong>
          <span>{timeAgo(post.createdAt, lang)}</span>
        </div>
        <button
          type="button"
          className="icon-btn"
          aria-label={t('post.options')}
          onClick={() => openSheet({ kind: 'postMenu', postId: post.id })}
        >
          <MoreHorizontal aria-hidden="true" />
        </button>
      </header>

      <div className="post__media" onDoubleClick={doubleTapLike}>
        <SafeImage
          src={sized(post.image, 900)}
          alt={t('post.imageAlt', { name: author.name })}
          ratio={Math.min(Math.max(post.ratio, 0.8), 1.25)}
          eager={priority}
        />
        {burst > 0 && <Heart key={burst} className="post__burst" aria-hidden="true" fill="currentColor" size={84} />}
      </div>

      <div className="post__actions">
        <button
          type="button"
          className={`icon-btn${liked ? ' is-liked' : ''}`}
          aria-pressed={liked}
          aria-label={liked ? t('post.unlike') : t('post.like')}
          onClick={toggleLike}
        >
          <Heart aria-hidden="true" fill={liked ? 'currentColor' : 'none'} />
        </button>
        <button
          type="button"
          className="icon-btn"
          aria-label={t('post.comment')}
          onClick={() => openSheet({ kind: 'comments', postId: post.id })}
        >
          <MessageCircle aria-hidden="true" />
        </button>
        <button type="button" className="icon-btn" aria-label={t('post.share')} onClick={share}>
          <Send aria-hidden="true" />
        </button>
        <button
          type="button"
          className={`icon-btn post__save${saved ? ' is-saved' : ''}`}
          aria-pressed={saved}
          aria-label={saved ? t('post.unsave') : t('post.save')}
          onClick={toggleSave}
        >
          <Bookmark aria-hidden="true" fill={saved ? 'currentColor' : 'none'} />
        </button>
      </div>

      <div className="post__body">
        {likeTotal > 0 && <strong className="post__likes">{t('post.likesN', { n: compact(likeTotal) })}</strong>}
        {post.caption && (
          <p className={`post__caption${expanded ? '' : ' is-clamped'}`}>
            <strong>{author.name}</strong> {post.caption}
          </p>
        )}
        {longCaption && (
          <button type="button" className="link-btn" onClick={() => setExpanded((v) => !v)}>
            {expanded ? t('post.lessText') : t('post.moreText')}
          </button>
        )}
        {commentTotal > 0 && (
          <button
            type="button"
            className="link-btn link-btn--muted"
            onClick={() => openSheet({ kind: 'comments', postId: post.id })}
          >
            {t('post.viewComments', { n: compact(commentTotal) })}
          </button>
        )}
      </div>
    </article>
  );
}
