import { useEffect, useRef, useState } from 'react';
import { ImageOff } from 'lucide-react';
import { useT } from '../i18n';

interface SafeImageProps {
  src: string;
  alt: string;
  /** width / height — reserves space so the page doesn't jump while loading */
  ratio?: number;
  className?: string;
  eager?: boolean;
}

export function SafeImage({ src, alt, ratio, className = '', eager = false }: SafeImageProps) {
  const t = useT();
  const ref = useRef<HTMLImageElement>(null);
  const [state, setState] = useState<'loading' | 'ok' | 'error'>('loading');

  useEffect(() => {
    setState('loading');
    const el = ref.current;
    if (el?.complete && el.naturalWidth > 0) setState('ok');
  }, [src]);

  return (
    <div
      className={`safeimg ${className}`}
      data-state={state}
      style={ratio ? { aspectRatio: String(ratio) } : undefined}
    >
      {state !== 'error' && (
        <img
          ref={ref}
          src={src}
          alt={alt}
          loading={eager ? 'eager' : 'lazy'}
          decoding="async"
          onLoad={() => setState('ok')}
          onError={() => setState('error')}
        />
      )}
      {state === 'error' && (
        <div className="safeimg__error" role="img" aria-label={alt}>
          <ImageOff size={22} aria-hidden="true" />
          <span>{t('common.imageFailed')}</span>
        </div>
      )}
    </div>
  );
}
