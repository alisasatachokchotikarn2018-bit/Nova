import type { CSSProperties } from 'react';
import { initials } from '../lib/format';

interface AvatarProps {
  name: string;
  hue?: number;
  src?: string;
  size?: number;
  className?: string;
}

/** Photo avatar, or a generated gradient with initials — no third-party avatar service needed. */
export function Avatar({ name, hue = 205, src, size = 40, className = '' }: AvatarProps) {
  const style: CSSProperties = { width: size, height: size };
  if (src) {
    return <img className={`avatar ${className}`} src={src} alt="" width={size} height={size} style={style} />;
  }
  return (
    <span
      className={`avatar avatar--initials ${className}`}
      aria-hidden="true"
      style={{
        ...style,
        fontSize: Math.round(size * 0.38),
        background: `linear-gradient(135deg, hsl(${hue} 78% 58%), hsl(${(hue + 45) % 360} 70% 40%))`,
      }}
    >
      {initials(name)}
    </span>
  );
}
