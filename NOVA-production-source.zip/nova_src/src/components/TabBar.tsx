import { Compass, GalleryVertical, Home, Plus, User } from 'lucide-react';
import { useT } from '../i18n';
import { navigate, paths, type RouteName } from '../lib/router';
import { useUi } from '../ui/UiContext';

export function TabBar({ route }: { route: RouteName }) {
  const t = useT();
  const { openSheet } = useUi();

  const tab = (name: RouteName, path: string, label: string, Icon: typeof Home) => (
    <button
      type="button"
      className="tab"
      aria-current={route === name ? 'page' : undefined}
      onClick={() => navigate(path)}
    >
      <Icon size={22} aria-hidden="true" />
      <span>{label}</span>
    </button>
  );

  return (
    <nav className="tabbar" aria-label={t('nav.label')}>
      {tab('home', paths.home, t('nav.home'), Home)}
      {tab('reels', paths.reels, t('nav.highlights'), GalleryVertical)}
      <button type="button" className="tab tab--create" aria-label={t('nav.create')} onClick={() => openSheet({ kind: 'create' })}>
        <span className="tab__plus">
          <Plus size={24} strokeWidth={2.6} aria-hidden="true" />
        </span>
      </button>
      {tab('explore', paths.explore, t('nav.explore'), Compass)}
      {tab('profile', paths.profile, t('nav.profile'), User)}
    </nav>
  );
}
