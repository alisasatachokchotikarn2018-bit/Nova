import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { LegalKind } from '../i18n/legal';

export type SheetState =
  | { kind: 'create' }
  | { kind: 'comments'; postId: string }
  | { kind: 'postMenu'; postId: string }
  | { kind: 'post'; postId: string }
  | { kind: 'report'; postId: string }
  | { kind: 'confirm'; action: 'deletePost'; postId: string }
  | { kind: 'confirm'; action: 'resetAll' }
  | { kind: 'editProfile' }
  | { kind: 'settings' }
  | { kind: 'legal'; doc: LegalKind }
  | { kind: 'newChat' }
  | { kind: 'story'; creatorId: string };

interface UiValue {
  sheet: SheetState | null;
  openSheet: (s: SheetState) => void;
  /** Closes the current sheet; `then` runs once it is closed (e.g. to navigate). */
  closeSheet: (then?: () => void) => void;
  toast: (message: string) => void;
  toastMessage: { id: number; text: string } | null;
}

const UiContext = createContext<UiValue | null>(null);

/**
 * Sheets push a history entry so the device Back button closes the sheet
 * instead of leaving the app.
 */
export function UiProvider({ children }: { children: ReactNode }) {
  const [sheet, setSheet] = useState<SheetState | null>(null);
  const [toastMessage, setToastMessage] = useState<{ id: number; text: string } | null>(null);
  const isOpen = useRef(false);
  const afterClose = useRef<(() => void) | null>(null);
  const toastTimer = useRef<number | undefined>(undefined);
  const toastId = useRef(0);

  const openSheet = useCallback((s: SheetState) => {
    if (!isOpen.current) {
      window.history.pushState({ novaSheet: true }, '');
      isOpen.current = true;
    }
    setSheet(s);
  }, []);

  const closeSheet = useCallback((then?: () => void) => {
    afterClose.current = then ?? null;
    if (isOpen.current) {
      window.history.back();
    } else {
      setSheet(null);
      const cb = afterClose.current;
      afterClose.current = null;
      cb?.();
    }
  }, []);

  useEffect(() => {
    const onPop = () => {
      if (!isOpen.current) return;
      isOpen.current = false;
      setSheet(null);
      const cb = afterClose.current;
      afterClose.current = null;
      if (cb) window.setTimeout(cb, 0);
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const toast = useCallback((text: string) => {
    window.clearTimeout(toastTimer.current);
    toastId.current += 1;
    setToastMessage({ id: toastId.current, text });
    toastTimer.current = window.setTimeout(() => setToastMessage(null), 2800);
  }, []);

  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  const value = useMemo(
    () => ({ sheet, openSheet, closeSheet, toast, toastMessage }),
    [sheet, openSheet, closeSheet, toast, toastMessage],
  );
  return <UiContext.Provider value={value}>{children}</UiContext.Provider>;
}

export function useUi(): UiValue {
  const ctx = useContext(UiContext);
  if (!ctx) throw new Error('useUi must be used inside UiProvider');
  return ctx;
}
