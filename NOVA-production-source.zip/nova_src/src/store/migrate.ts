import { LIMITS } from '../config';
import type { Comment, Message, Post, Report } from '../types';
import type { State } from './AppStore';

/**
 * Bump when the persisted shape changes, and add a step to `upgrade()`.
 * Old saves must always keep loading: users' data outlives any single app version.
 */
export const SCHEMA_VERSION = 1;

const DATA_IMAGE = /^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/;

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);
const str = (v: unknown, fallback = '', max = Infinity): string => (typeof v === 'string' ? v.slice(0, max) : fallback);
const num = (v: unknown, fallback = 0): number => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const strings = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);

/** Steps that bring an older save up to the current schema. */
function upgrade(data: Obj, from: number): Obj {
  const next = { ...data };
  // v0 -> v1: introduced the `v` field; shape unchanged.
  if (from < 1) {
    /* nothing to transform */
  }
  // Future: if (from < 2) { ...transform next... }
  return next;
}

function comments(v: unknown): Comment[] {
  if (!Array.isArray(v)) return [];
  return v.filter(isObj).map((c, i) => ({
    id: str(c.id, `c${i}`),
    authorId: str(c.authorId, 'me'),
    text: str(c.text, '', LIMITS.comment),
    at: num(c.at, Date.now()),
  }));
}

function posts(v: unknown): Post[] {
  if (!Array.isArray(v)) return [];
  const out: Post[] = [];
  for (const p of v) {
    if (!isObj(p) || typeof p.id !== 'string') continue;
    const image = str(p.image);
    if (image && !DATA_IMAGE.test(image)) continue; // own posts only ever hold data URLs
    out.push({
      id: p.id,
      authorId: 'me',
      image,
      ratio: Math.min(4, Math.max(0.25, num(p.ratio, 1))),
      caption: str(p.caption, '', LIMITS.caption),
      tags: strings(p.tags),
      category: 'photo',
      createdAt: num(p.createdAt, Date.now()),
      likes: 0,
      commentCount: 0,
      comments: [],
    });
  }
  return out;
}

function messages(v: unknown): Message[] {
  if (!Array.isArray(v)) return [];
  return v.filter(isObj).map((m, i) => ({
    id: str(m.id, `m${i}`),
    from: m.from === 'me' ? 'me' : 'them',
    text: str(m.text, '', LIMITS.message),
    at: num(m.at, Date.now()),
  }));
}

function reports(v: unknown): Report[] {
  if (!Array.isArray(v)) return [];
  return v.filter(isObj).map((r) => ({ postId: str(r.postId), reason: str(r.reason), at: num(r.at, Date.now()) }));
}

function mapOf<T>(v: unknown, convert: (x: unknown) => T): Record<string, T> {
  if (!isObj(v)) return {};
  return Object.fromEntries(Object.entries(v).map(([k, val]) => [k, convert(val)]));
}

/**
 * Turns anything read from storage or a backup file into a safe State.
 * Unknown / corrupt fields fall back to `base`, so bad data can never crash the app.
 */
export function restoreState(raw: unknown, base: State): State {
  if (!isObj(raw)) return base;
  const from = typeof raw.v === 'number' ? raw.v : 0;
  const d = upgrade(raw, from);
  const profile = isObj(d.profile) ? d.profile : {};
  const avatar = str(profile.avatar);

  return {
    profile: {
      name: str(profile.name, base.profile.name, LIMITS.name).trim() || base.profile.name,
      handle: str(profile.handle, base.profile.handle, LIMITS.handleMax) || base.profile.handle,
      bio: str(profile.bio, '', LIMITS.bio),
      avatar: DATA_IMAGE.test(avatar) ? avatar : '',
    },
    myPosts: posts(d.myPosts),
    comments: mapOf(d.comments, comments),
    liked: strings(d.liked),
    saved: strings(d.saved),
    hidden: strings(d.hidden),
    blocked: strings(d.blocked),
    following: strings(d.following),
    reports: reports(d.reports),
    threads: isObj(d.threads) ? { ...base.threads, ...mapOf(d.threads, messages) } : base.threads,
    unread: isObj(d.unread) ? mapOf(d.unread, (n) => Math.max(0, Math.floor(num(n)))) : base.unread,
    seenStories: strings(d.seenStories),
    lang: d.lang === 'th' || d.lang === 'en' ? d.lang : base.lang,
    theme: d.theme === 'light' || d.theme === 'dark' || d.theme === 'system' ? d.theme : base.theme,
  };
}
