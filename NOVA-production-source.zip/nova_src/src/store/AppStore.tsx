import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
  type Dispatch,
  type ReactNode,
} from 'react';
import { STORAGE_KEY } from '../config';
import { CREATOR_MAP, SEED_POSTS, UNKNOWN_AUTHOR, seedThreads, seedUnread } from '../data/seed';
import { loadJSON, removeKey, saveJSON } from '../lib/storage';
import { uid } from '../lib/format';
import { requestPersistentStorage } from '../lib/pwa';
import { restoreState, SCHEMA_VERSION } from './migrate';
import type { Author, Comment, Lang, Message, Post, Profile, Report, ThemePref } from '../types';

export interface State {
  profile: Profile;
  myPosts: Post[];
  comments: Record<string, Comment[]>;
  liked: string[];
  saved: string[];
  hidden: string[];
  blocked: string[];
  following: string[];
  reports: Report[];
  threads: Record<string, Message[]>;
  unread: Record<string, number>;
  seenStories: string[];
  lang: Lang;
  theme: ThemePref;
}

export type Action =
  | { type: 'toggleLike'; id: string }
  | { type: 'toggleSave'; id: string }
  | { type: 'toggleFollow'; id: string }
  | { type: 'addPost'; post: Post }
  | { type: 'deletePost'; id: string }
  | { type: 'addComment'; postId: string; text: string }
  | { type: 'hidePost'; id: string }
  | { type: 'blockUser'; id: string }
  | { type: 'report'; postId: string; reason: string }
  | { type: 'sendMessage'; threadId: string; text: string }
  | { type: 'readThread'; threadId: string }
  | { type: 'seeStory'; id: string }
  | { type: 'setProfile'; profile: Partial<Profile> }
  | { type: 'setLang'; lang: Lang }
  | { type: 'setTheme'; theme: ThemePref }
  | { type: 'restore'; state: State };

const toggle = (list: string[], id: string) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

function defaults(): State {
  const lang: Lang = navigator.language?.toLowerCase().startsWith('th') ? 'th' : 'en';
  return {
    profile: {
      name: lang === 'th' ? 'ผู้ใช้ NOVA' : 'NOVA user',
      handle: 'user' + Math.floor(1000 + Math.random() * 9000),
      bio: '',
      avatar: '',
    },
    myPosts: [],
    comments: {},
    liked: [],
    saved: [],
    hidden: [],
    blocked: [],
    following: [],
    reports: [],
    threads: seedThreads(),
    unread: seedUnread(),
    seenStories: [],
    lang,
    theme: 'system',
  };
}

function init(): State {
  const base = defaults();
  return restoreState(loadJSON<unknown>(STORAGE_KEY), base);
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'toggleLike':
      return { ...state, liked: toggle(state.liked, action.id) };
    case 'toggleSave':
      return { ...state, saved: toggle(state.saved, action.id) };
    case 'toggleFollow':
      return { ...state, following: toggle(state.following, action.id) };
    case 'addPost':
      return { ...state, myPosts: [action.post, ...state.myPosts] };
    case 'deletePost':
      return {
        ...state,
        myPosts: state.myPosts.filter((p) => p.id !== action.id),
        saved: state.saved.filter((x) => x !== action.id),
        liked: state.liked.filter((x) => x !== action.id),
      };
    case 'addComment': {
      const comment: Comment = { id: uid(), authorId: 'me', text: action.text, at: Date.now() };
      return {
        ...state,
        comments: { ...state.comments, [action.postId]: [...(state.comments[action.postId] ?? []), comment] },
      };
    }
    case 'hidePost':
      return state.hidden.includes(action.id) ? state : { ...state, hidden: [...state.hidden, action.id] };
    case 'blockUser':
      return state.blocked.includes(action.id)
        ? state
        : { ...state, blocked: [...state.blocked, action.id], following: state.following.filter((x) => x !== action.id) };
    case 'report':
      return {
        ...state,
        reports: [...state.reports, { postId: action.postId, reason: action.reason, at: Date.now() }],
        hidden: state.hidden.includes(action.postId) ? state.hidden : [...state.hidden, action.postId],
      };
    case 'sendMessage': {
      const msg: Message = { id: uid(), from: 'me', text: action.text, at: Date.now() };
      return { ...state, threads: { ...state.threads, [action.threadId]: [...(state.threads[action.threadId] ?? []), msg] } };
    }
    case 'readThread': {
      if (!state.unread[action.threadId]) return state;
      const unread = { ...state.unread };
      delete unread[action.threadId];
      return { ...state, unread };
    }
    case 'seeStory':
      return state.seenStories.includes(action.id) ? state : { ...state, seenStories: [...state.seenStories, action.id] };
    case 'setProfile':
      return { ...state, profile: { ...state.profile, ...action.profile } };
    case 'setLang':
      return { ...state, lang: action.lang };
    case 'setTheme':
      return { ...state, theme: action.theme };
    case 'restore':
      return action.state;
    default:
      return state;
  }
}

interface StoreValue {
  state: State;
  dispatch: Dispatch<Action>;
  storageFailed: boolean;
  resetAll: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, init);
  const [storageFailed, setStorageFailed] = useState(false);
  const persistEnabled = useRef(true);

  useEffect(() => {
    if (!persistEnabled.current) return;
    const timer = window.setTimeout(() => {
      if (!persistEnabled.current) return;
      setStorageFailed(!saveJSON(STORAGE_KEY, { v: SCHEMA_VERSION, ...state }));
    }, 300);
    return () => window.clearTimeout(timer);
  }, [state]);

  useEffect(() => {
    void requestPersistentStorage();
  }, []);

  const resetAll = useCallback(() => {
    persistEnabled.current = false;
    removeKey(STORAGE_KEY);
    window.location.hash = '';
    window.location.reload();
  }, []);

  const value = useMemo(() => ({ state, dispatch, storageFailed, resetAll }), [state, storageFailed, resetAll]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside AppProvider');
  return ctx;
}

/** Posts visible to the user (hidden posts and blocked authors removed), newest first. */
export function useFeed(): Post[] {
  const {
    state: { myPosts, hidden, blocked },
  } = useStore();
  return useMemo(() => {
    const hiddenSet = new Set(hidden);
    const blockedSet = new Set(blocked);
    return [...myPosts, ...SEED_POSTS]
      .filter((p) => !hiddenSet.has(p.id) && !blockedSet.has(p.authorId))
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [myPosts, hidden, blocked]);
}

export function resolveAuthor(id: string, profile: Profile): Author {
  if (id === 'me') {
    return { id: 'me', name: profile.name, handle: profile.handle, hue: 205, avatar: profile.avatar || undefined };
  }
  return CREATOR_MAP[id] ?? UNKNOWN_AUTHOR;
}

export function findPost(id: string, myPosts: Post[]): Post | undefined {
  return myPosts.find((p) => p.id === id) ?? SEED_POSTS.find((p) => p.id === id);
}
