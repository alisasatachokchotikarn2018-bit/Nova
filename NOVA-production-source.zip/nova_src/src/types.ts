export type Lang = 'th' | 'en';
export type ThemePref = 'system' | 'light' | 'dark';
export type Category = 'photo' | 'nature' | 'travel' | 'city';

export interface Creator {
  id: string;
  name: string;
  handle: string;
  hue: number;
  verified?: boolean;
  online?: boolean;
  /** Unsplash photo ids shown in the story viewer */
  stories?: string[];
}

export interface Author {
  id: string;
  name: string;
  handle: string;
  hue: number;
  verified?: boolean;
  avatar?: string;
}

export interface Comment {
  id: string;
  authorId: string;
  text: string;
  at: number;
}

export interface Post {
  id: string;
  authorId: string;
  /** Full image URL or data URL (user uploads) */
  image: string;
  /** width / height, used to reserve space and avoid layout shift */
  ratio: number;
  caption: string;
  tags: string[];
  category: Category;
  createdAt: number;
  likes: number;
  commentCount: number;
  comments: Comment[];
}

export interface Message {
  id: string;
  from: 'me' | 'them';
  text: string;
  at: number;
}

export interface Profile {
  name: string;
  handle: string;
  bio: string;
  avatar: string;
}

export interface Report {
  postId: string;
  reason: string;
  at: number;
}
