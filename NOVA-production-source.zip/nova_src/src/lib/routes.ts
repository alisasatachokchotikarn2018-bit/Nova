export type RouteName = 'home' | 'reels' | 'explore' | 'ai' | 'profile' | 'messages' | 'thread';

export interface Route {
  name: RouteName;
  id?: string;
}

/** Pure hash parser (no React) so it can be unit-tested. "#/messages/sarah" -> thread. */
export function parseHash(hash: string): Route {
  const parts = hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  switch (parts[0]) {
    case 'reels':
      return { name: 'reels' };
    case 'explore':
      return { name: 'explore' };
    case 'ai':
      return { name: 'ai' };
    case 'profile':
      return { name: 'profile' };
    case 'messages':
      return parts[1] ? { name: 'thread', id: safeDecode(parts[1]) } : { name: 'messages' };
    default:
      return { name: 'home' };
  }
}

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

export const paths = {
  home: '/',
  reels: '/reels',
  explore: '/explore',
  ai: '/ai',
  profile: '/profile',
  messages: '/messages',
  thread: (id: string) => `/messages/${encodeURIComponent(id)}`,
};
