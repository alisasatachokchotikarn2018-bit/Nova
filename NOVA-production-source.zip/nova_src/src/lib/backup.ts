import { APP_NAME } from '../config';
import { SCHEMA_VERSION } from '../store/migrate';
import type { State } from '../store/AppStore';

const MAX_BACKUP_BYTES = 25 * 1024 * 1024;

export type ExportResult = 'shared' | 'downloaded' | 'cancelled' | 'failed';

export function buildBackup(state: State): string {
  return JSON.stringify({ app: APP_NAME, v: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data: { v: SCHEMA_VERSION, ...state } });
}

const isNative = (): boolean =>
  Boolean((window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.());

/** Android/iOS app: write to the cache folder and open the system share sheet (WebViews can't download blobs). */
async function exportNative(json: string, name: string): Promise<ExportResult> {
  const [{ Filesystem, Directory, Encoding }, { Share }] = await Promise.all([
    import('@capacitor/filesystem'),
    import('@capacitor/share'),
  ]);
  await Filesystem.writeFile({ path: name, data: json, directory: Directory.Cache, encoding: Encoding.UTF8 });
  const { uri } = await Filesystem.getUri({ directory: Directory.Cache, path: name });
  await Share.share({ title: name, url: uri });
  return 'shared';
}

/** Saves the backup via the share sheet where possible, otherwise as a normal file download. */
export async function exportBackup(state: State): Promise<ExportResult> {
  const name = `nova-backup-${new Date().toISOString().slice(0, 10)}.json`;
  const json = buildBackup(state);
  try {
    if (isNative()) return await exportNative(json, name);
    const file = new File([json], name, { type: 'application/json' });
    if (typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: name });
      return 'shared';
    }
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 10_000);
    return 'downloaded';
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') return 'cancelled';
    if (err instanceof Error && /cancel/i.test(err.message)) return 'cancelled';
    return 'failed';
  }
}

/** Reads a backup file and returns the raw `data` object (to be sanitized by restoreState). */
export async function readBackup(file: File): Promise<unknown> {
  if (file.size > MAX_BACKUP_BYTES) throw new Error('too-large');
  const parsed: unknown = JSON.parse(await file.text());
  if (typeof parsed === 'object' && parsed !== null && 'data' in parsed) {
    const wrapped = parsed as { app?: unknown; data: unknown };
    if (wrapped.app !== APP_NAME) throw new Error('not-nova');
    return wrapped.data;
  }
  throw new Error('not-nova');
}
