import { LIMITS } from '../config';

export type ImageError = 'type' | 'size' | 'read';

const ACCEPTED = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

export function validateImage(file: File): ImageError | null {
  if (!ACCEPTED.includes(file.type)) return 'type';
  if (file.size > LIMITS.imageMaxMB * 1024 * 1024) return 'size';
  return null;
}

export interface ProcessedImage {
  dataUrl: string;
  ratio: number;
}

/**
 * Re-encodes the picked image through a canvas. This downsizes it so it fits in
 * local storage, and drops all EXIF metadata (including GPS location).
 */
export async function processImage(
  file: File,
  opts: { maxPx?: number; square?: boolean; quality?: number } = {},
): Promise<ProcessedImage> {
  const { maxPx = LIMITS.imageMaxPx, square = false, quality = 0.82 } = opts;
  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error('read');
  }

  let sx = 0;
  let sy = 0;
  let sw = bitmap.width;
  let sh = bitmap.height;
  if (square) {
    const side = Math.min(sw, sh);
    sx = Math.round((sw - side) / 2);
    sy = Math.round((sh - side) / 2);
    sw = side;
    sh = side;
  }
  const scale = Math.min(1, maxPx / Math.max(sw, sh));
  const w = Math.max(1, Math.round(sw * scale));
  const h = Math.max(1, Math.round(sh * scale));

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('read');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, w, h);
  bitmap.close();

  return { dataUrl: canvas.toDataURL('image/jpeg', quality), ratio: w / h };
}
