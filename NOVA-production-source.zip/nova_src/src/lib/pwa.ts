import { IS_PROD } from '../config';

/** Registers the offline service worker in production builds only. */
export function registerServiceWorker(): void {
  if (!IS_PROD || !('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then(() => navigator.serviceWorker.ready)
      .then((reg) => {
        const urls = performance
          .getEntriesByType('resource')
          .map((r) => r.name)
          .filter((n) => n.startsWith(window.location.origin) && /\.(js|css)(\?|$)/.test(n));
        reg.active?.postMessage({ type: 'CACHE_URLS', urls });
      })
      .catch(() => {
        /* offline support is an enhancement; the app works without it */
      });
  });
}

/** Asks the browser not to evict our data under storage pressure. */
export async function requestPersistentStorage(): Promise<void> {
  try {
    if (navigator.storage?.persist && !(await navigator.storage.persisted())) await navigator.storage.persist();
  } catch {
    /* not supported — ignore */
  }
}
