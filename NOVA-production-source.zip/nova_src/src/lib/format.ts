import type { Lang } from '../types';

const compactFmt = new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 });

export function compact(n: number): string {
  return compactFmt.format(Math.max(0, n));
}

const UNITS: [Intl.RelativeTimeFormatUnit, number][] = [
  ['year', 31_536_000],
  ['month', 2_592_000],
  ['week', 604_800],
  ['day', 86_400],
  ['hour', 3_600],
  ['minute', 60],
];

export function timeAgo(ts: number, lang: Lang, now = Date.now()): string {
  const secs = Math.max(0, Math.round((now - ts) / 1000));
  if (secs < 45) return lang === 'th' ? 'เมื่อสักครู่' : 'just now';
  const rtf = new Intl.RelativeTimeFormat(lang, { numeric: 'always', style: 'short' });
  for (const [unit, size] of UNITS) {
    if (secs >= size) return rtf.format(-Math.floor(secs / size), unit);
  }
  return rtf.format(-1, 'minute');
}

export function clockTime(ts: number, lang: Lang): string {
  return new Date(ts).toLocaleTimeString(lang === 'th' ? 'th-TH' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function dayLabel(ts: number, lang: Lang, todayLabel: string): string {
  const d = new Date(ts);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return todayLabel;
  return d.toLocaleDateString(lang === 'th' ? 'th-TH' : 'en-US', { day: 'numeric', month: 'short' });
}

export function uid(): string {
  const c = globalThis.crypto as Crypto | undefined;
  if (c && 'randomUUID' in c) return c.randomUUID();
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

/** Thai leading vowels sit before the consonant they belong to, so skip them for an initial. */
const THAI_LEADING_VOWELS = /^[เแโใไ]+/;
const LATIN = /^[A-Za-z]/;

export function firstChar(name: string): string {
  const clean = name.trim().replace(THAI_LEADING_VOWELS, '');
  return Array.from(clean || name.trim())[0]?.toUpperCase() ?? '?';
}

/** "Maya Lin" -> "ML"; Thai or mixed-script names -> a single clean character. */
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length >= 2 && LATIN.test(parts[0]) && LATIN.test(parts[1])) {
    return (firstChar(parts[0]) + firstChar(parts[1])).slice(0, 2);
  }
  return firstChar(name);
}
