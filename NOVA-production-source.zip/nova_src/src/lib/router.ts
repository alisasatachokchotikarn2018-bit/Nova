import { useEffect, useMemo, useState } from 'react';
import { parseHash, paths, type Route, type RouteName } from './routes';

export { parseHash, paths };
export type { Route, RouteName };

export function useRoute(): Route {
  const [hash, setHash] = useState(() => window.location.hash);
  useEffect(() => {
    const update = () => setHash(window.location.hash);
    window.addEventListener('hashchange', update);
    window.addEventListener('popstate', update);
    return () => {
      window.removeEventListener('hashchange', update);
      window.removeEventListener('popstate', update);
    };
  }, []);
  return useMemo(() => parseHash(hash), [hash]);
}

export function navigate(path: string): void {
  const target = '#' + path;
  if (window.location.hash !== target) window.location.hash = path;
}
