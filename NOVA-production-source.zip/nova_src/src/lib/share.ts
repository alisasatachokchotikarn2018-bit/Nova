/** Uses the native share sheet when available, otherwise copies the link. */
export async function shareLink(text: string): Promise<'shared' | 'copied' | 'cancelled' | 'failed'> {
  const url = window.location.origin + window.location.pathname;
  try {
    if (typeof navigator.share === 'function') {
      await navigator.share({ title: 'NOVA', text, url });
      return 'shared';
    }
    await navigator.clipboard.writeText(`${text} ${url}`);
    return 'copied';
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') return 'cancelled';
    return 'failed';
  }
}
