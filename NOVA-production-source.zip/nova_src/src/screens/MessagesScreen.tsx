import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, MessageCircle, Plus, Search, Send } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { EmptyState } from '../components/Common';
import { CREATOR_MAP, CREATORS } from '../data/seed';
import { useLang, useT } from '../i18n';
import { LIMITS } from '../config';
import { clockTime, dayLabel } from '../lib/format';
import { navigate, paths } from '../lib/router';
import { useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function MessagesScreen() {
  const t = useT();
  const lang = useLang();
  const { state } = useStore();
  const { openSheet } = useUi();
  const [query, setQuery] = useState('');

  const threads = useMemo(() => {
    const q = query.trim().toLowerCase();
    return Object.entries(state.threads)
      .filter(([id, msgs]) => msgs.length > 0 && CREATOR_MAP[id] && !state.blocked.includes(id))
      .map(([id, msgs]) => ({ creator: CREATOR_MAP[id], last: msgs[msgs.length - 1] }))
      .filter(({ creator, last }) => !q || (creator.name + ' ' + last.text).toLowerCase().includes(q))
      .sort((a, b) => b.last.at - a.last.at);
  }, [state.threads, state.blocked, query]);

  const online = CREATORS.filter((c) => c.online && !state.blocked.includes(c.id));

  return (
    <div className="messages">
      <header className="topbar topbar--center">
        <button type="button" className="icon-btn" aria-label={t('common.back')} onClick={() => navigate(paths.home)}>
          <ArrowLeft aria-hidden="true" />
        </button>
        <h1 className="topbar__title">{t('msg.title')}</h1>
        <button type="button" className="icon-btn icon-btn--tint" aria-label={t('msg.new')} onClick={() => openSheet({ kind: 'newChat' })}>
          <Plus aria-hidden="true" />
        </button>
      </header>

      <div className="searchbox searchbox--inline">
        <Search size={18} aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('msg.search')}
          aria-label={t('msg.search')}
        />
      </div>

      {online.length > 0 && !query && (
        <section aria-label={t('msg.active')}>
          <h2 className="section-label">{t('msg.active')}</h2>
          <ul className="online-row">
            {online.map((c) => (
              <li key={c.id}>
                <button type="button" className="online" aria-label={t('msg.open', { name: c.name })} onClick={() => navigate(paths.thread(c.id))}>
                  <span className="online__avatar">
                    <Avatar name={c.name} hue={c.hue} size={54} />
                    <i aria-hidden="true" />
                  </span>
                  <span>{c.name.split(' ')[0]}</span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {threads.length === 0 ? (
        <EmptyState
          icon={<MessageCircle size={30} />}
          title={query ? t('msg.noMatch') : t('msg.empty')}
          body={query ? undefined : t('msg.emptyBody')}
        />
      ) : (
        <ul className="chat-list">
          {threads.map(({ creator, last }) => {
            const unread = state.unread[creator.id] ?? 0;
            return (
              <li key={creator.id}>
                <button
                  type="button"
                  className={`chat-row${unread ? ' is-unread' : ''}`}
                  onClick={() => navigate(paths.thread(creator.id))}
                >
                  <Avatar name={creator.name} hue={creator.hue} size={50} />
                  <span className="chat-row__text">
                    <strong>{creator.name}</strong>
                    <small>
                      {last.from === 'me' ? t('msg.you') : ''}
                      {last.text}
                    </small>
                  </span>
                  <span className="chat-row__meta">
                    <small>{dayLabel(last.at, lang, clockTime(last.at, lang))}</small>
                    {unread > 0 && <span className="badge badge--inline">{unread}</span>}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

export function ThreadScreen({ id }: { id: string }) {
  const t = useT();
  const lang = useLang();
  const { state, dispatch } = useStore();
  const creator = CREATOR_MAP[id];
  const messages = state.threads[id] ?? [];
  const [draft, setDraft] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    dispatch({ type: 'readThread', threadId: id });
  }, [id, dispatch]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' });
  }, [messages.length]);

  if (!creator || state.blocked.includes(id)) {
    return (
      <div className="messages">
        <header className="topbar topbar--center">
          <button type="button" className="icon-btn" aria-label={t('common.back')} onClick={() => navigate(paths.messages)}>
            <ArrowLeft aria-hidden="true" />
          </button>
          <h1 className="topbar__title">{t('msg.title')}</h1>
          <span className="topbar__spacer" aria-hidden="true" />
        </header>
        <EmptyState icon={<MessageCircle size={30} />} title={t('msg.unknown')} />
      </div>
    );
  }

  const send = () => {
    const text = draft.trim();
    if (!text) return;
    dispatch({ type: 'sendMessage', threadId: id, text });
    setDraft('');
  };

  let lastDay = '';
  return (
    <div className="thread">
      <header className="topbar topbar--center">
        <button type="button" className="icon-btn" aria-label={t('common.back')} onClick={() => navigate(paths.messages)}>
          <ArrowLeft aria-hidden="true" />
        </button>
        <div className="thread__who">
          <Avatar name={creator.name} hue={creator.hue} size={38} />
          <div>
            <strong>{creator.name}</strong>
            {creator.online && <small>● {t('msg.online')}</small>}
          </div>
        </div>
        <span className="topbar__spacer" aria-hidden="true" />
      </header>

      <div className="thread__body" role="log" aria-live="polite">
        {messages.map((m) => {
          const day = dayLabel(m.at, lang, t('msg.today'));
          const showDay = day !== lastDay;
          lastDay = day;
          return (
            <div key={m.id} className="thread__item">
              {showDay && <div className="day-label">{day}</div>}
              <div className={`msg msg--${m.from}`}>
                {m.text}
                <time dateTime={new Date(m.at).toISOString()}>{clockTime(m.at, lang)}</time>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      <form
        className="composer"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={t('msg.placeholder')}
          aria-label={t('msg.placeholder')}
          maxLength={LIMITS.message}
          enterKeyHint="send"
        />
        <button type="submit" className="send-btn" disabled={!draft.trim()} aria-label={t('common.send')}>
          <Send size={18} aria-hidden="true" />
        </button>
      </form>
    </div>
  );
}
