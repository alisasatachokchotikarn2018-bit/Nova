import { useMemo, useState } from 'react';
import { Heart, Search, SearchX, X } from 'lucide-react';
import { EmptyState } from '../components/Common';
import { SafeImage } from '../components/SafeImage';
import { sized } from '../data/seed';
import { useT } from '../i18n';
import type { Key } from '../i18n/th';
import { compact } from '../lib/format';
import { resolveAuthor, useFeed, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';
import type { Category } from '../types';

type Filter = 'all' | Category;
const FILTERS: Filter[] = ['all', 'photo', 'nature', 'travel', 'city'];

export function ExploreScreen() {
  const t = useT();
  const { state } = useStore();
  const { openSheet } = useUi();
  const feed = useFeed();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return feed.filter((p) => {
      if (filter !== 'all' && p.category !== filter) return false;
      if (!q) return true;
      const author = resolveAuthor(p.authorId, state.profile);
      const haystack = [p.caption, author.name, author.handle, ...p.tags].join(' ').toLowerCase();
      return haystack.includes(q);
    });
  }, [feed, filter, query, state.profile]);

  return (
    <>
      <header className="topbar topbar--stack">
        <h1 className="screen-title">{t('explore.title')}</h1>
        <div className="searchbox">
          <Search size={18} aria-hidden="true" />
          <input
            type="search"
            inputMode="search"
            enterKeyHint="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('explore.search')}
            aria-label={t('explore.search')}
          />
          {query && (
            <button type="button" className="icon-btn icon-btn--sm" aria-label={t('explore.clear')} onClick={() => setQuery('')}>
              <X size={16} aria-hidden="true" />
            </button>
          )}
        </div>
        <div className="chips" role="group" aria-label={t('explore.filters')}>
          {FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              className={`chip${filter === f ? ' is-active' : ''}`}
              aria-pressed={filter === f}
              onClick={() => setFilter(f)}
            >
              {t(`explore.cat.${f}` as Key)}
            </button>
          ))}
        </div>
      </header>

      {results.length === 0 ? (
        <EmptyState icon={<SearchX size={30} />} title={t('explore.noResults')} body={t('explore.noResultsBody')} />
      ) : (
        <div className="masonry">
          {results.map((p) => {
            const author = resolveAuthor(p.authorId, state.profile);
            return (
              <button
                key={p.id}
                type="button"
                className="tile"
                aria-label={t('explore.open', { name: author.name })}
                onClick={() => openSheet({ kind: 'post', postId: p.id })}
              >
                <SafeImage src={sized(p.image, 500)} alt="" ratio={p.ratio} />
                <span className="tile__scrim" aria-hidden="true" />
                <span className="tile__likes" aria-hidden="true">
                  <Heart size={13} fill="currentColor" />
                  {compact(p.likes + (state.liked.includes(p.id) ? 1 : 0))}
                </span>
                {p.caption && (
                  <span className="tile__caption" aria-hidden="true">
                    {p.caption}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </>
  );
}
