import { Compass, MessageCircle, Sparkles } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { EmptyState } from '../components/Common';
import { PostCard } from '../components/PostCard';
import { CREATORS } from '../data/seed';
import { useT } from '../i18n';
import { navigate, paths } from '../lib/router';
import { useFeed, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function HomeScreen() {
  const t = useT();
  const { state } = useStore();
  const { openSheet } = useUi();
  const posts = useFeed();
  const unread = Object.values(state.unread).reduce((a, b) => a + b, 0);
  const stories = CREATORS.filter((c) => c.stories?.length && !state.blocked.includes(c.id));

  return (
    <>
      <header className="topbar">
        <h1 className="logo">NOVA</h1>
        <div className="topbar__actions">
          <button type="button" className="icon-btn" aria-label={t('home.ai')} onClick={() => navigate(paths.ai)}>
            <Sparkles aria-hidden="true" />
          </button>
          <button
            type="button"
            className="icon-btn icon-btn--badge"
            aria-label={unread > 0 ? `${t('home.messages')} (${t('msg.unread', { n: unread })})` : t('home.messages')}
            onClick={() => navigate(paths.messages)}
          >
            <MessageCircle aria-hidden="true" />
            {unread > 0 && (
              <span className="badge" aria-hidden="true">
                {unread}
              </span>
            )}
          </button>
        </div>
      </header>

      {stories.length > 0 && (
        <ul className="stories" aria-label={t('home.stories')}>
          {stories.map((c) => {
            const seen = state.seenStories.includes(c.id);
            return (
              <li key={c.id}>
                <button
                  type="button"
                  className="story"
                  aria-label={t('story.of', { name: c.name })}
                  onClick={() => openSheet({ kind: 'story', creatorId: c.id })}
                >
                  <span className={`story__ring${seen ? ' is-seen' : ''}`}>
                    <Avatar name={c.name} hue={c.hue} size={56} />
                  </span>
                  <span className="story__name">{c.name}</span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {posts.length === 0 ? (
        <EmptyState
          icon={<Compass size={30} />}
          title={t('home.emptyTitle')}
          body={t('home.emptyBody')}
          action={
            <button type="button" className="btn btn--primary" onClick={() => navigate(paths.explore)}>
              {t('home.emptyCta')}
            </button>
          }
        />
      ) : (
        posts.map((post, i) => <PostCard key={post.id} post={post} priority={i === 0} />)
      )}
    </>
  );
}
