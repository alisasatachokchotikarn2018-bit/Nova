import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Image as ImageIcon, Lightbulb, Send, Sparkles } from 'lucide-react';
import { useLang, useT } from '../i18n';
import { navigate, paths } from '../lib/router';
import { askNova } from '../services/novaAi';

interface ChatMessage {
  id: number;
  role: 'user' | 'bot';
  text: string;
  error?: boolean;
}

export function AiScreen() {
  const t = useT();
  const lang = useLang();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [pending, setPending] = useState(false);
  const nextId = useRef(1);
  const abortRef = useRef<AbortController | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => () => abortRef.current?.abort(), []);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' });
  }, [messages, pending]);

  const send = async (raw: string) => {
    const text = raw.trim();
    if (!text || pending) return;
    setMessages((m) => [...m, { id: nextId.current++, role: 'user', text }]);
    setDraft('');
    setPending(true);
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const reply = await askNova(text, lang, controller.signal);
      setMessages((m) => [...m, { id: nextId.current++, role: 'bot', text: reply }]);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      setMessages((m) => [...m, { id: nextId.current++, role: 'bot', text: t('ai.error'), error: true }]);
    } finally {
      setPending(false);
    }
  };

  const suggestions = [
    { icon: <Sparkles size={18} aria-hidden="true" />, label: t('ai.s1') },
    { icon: <ImageIcon size={18} aria-hidden="true" />, label: t('ai.s2') },
    { icon: <Lightbulb size={18} aria-hidden="true" />, label: t('ai.s3') },
  ];

  return (
    <div className="ai">
      <header className="topbar topbar--center">
        <button type="button" className="icon-btn" aria-label={t('common.back')} onClick={() => navigate(paths.home)}>
          <ArrowLeft aria-hidden="true" />
        </button>
        <h1 className="topbar__title">
          {t('ai.title')} <span className="pill">{t('ai.beta')}</span>
        </h1>
        <span className="topbar__spacer" aria-hidden="true" />
      </header>

      <div className="ai__body">
        {messages.length === 0 && (
          <div className="ai__hello">
            <div className="orb" aria-hidden="true" />
            <h2>{t('ai.hello')}</h2>
            <p>{t('ai.sub')}</p>
            <div className="ai__suggestions">
              {suggestions.map((s) => (
                <button key={s.label} type="button" className="suggestion" onClick={() => send(s.label)}>
                  {s.icon}
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="ai__log" role="log" aria-live="polite">
          {messages.map((m) => (
            <div key={m.id} className={`bubble bubble--${m.role}${m.error ? ' bubble--error' : ''}`}>
              <span className="sr-only">{m.role === 'user' ? t('ai.you') : t('ai.bot')}: </span>
              {m.text}
            </div>
          ))}
          {pending && (
            <div className="bubble bubble--bot bubble--typing" aria-label={t('ai.thinking')}>
              <i />
              <i />
              <i />
            </div>
          )}
        </div>
        <div ref={endRef} />
      </div>

      <form
        className="composer"
        onSubmit={(e) => {
          e.preventDefault();
          void send(draft);
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={t('ai.placeholder')}
          aria-label={t('ai.placeholder')}
          maxLength={1000}
          enterKeyHint="send"
        />
        <button type="submit" className="send-btn" disabled={!draft.trim() || pending} aria-label={t('common.send')}>
          <Send size={18} aria-hidden="true" />
        </button>
      </form>
      <p className="ai__note">{t('ai.disclaimer')}</p>
    </div>
  );
}
