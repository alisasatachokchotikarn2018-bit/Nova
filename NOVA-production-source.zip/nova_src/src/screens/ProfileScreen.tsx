import { useMemo, useState } from 'react';
import { Bookmark, Camera, Heart, Settings } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { EmptyState } from '../components/Common';
import { SafeImage } from '../components/SafeImage';
import { sized } from '../data/seed';
import { useT } from '../i18n';
import { compact } from '../lib/format';
import { useFeed, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';

export function ProfileScreen() {
  const t = useT();
  const { state } = useStore();
  const { openSheet } = useUi();
  const feed = useFeed();
  const [tab, setTab] = useState<'posts' | 'saved'>('posts');
  const { profile } = state;

  const posts = state.myPosts;
  const savedPosts = useMemo(() => feed.filter((p) => state.saved.includes(p.id)), [feed, state.saved]);
  const shown = tab === 'posts' ? posts : savedPosts;

  return (
    <>
      <div className="cover">
        <button
          type="button"
          className="icon-btn icon-btn--glass cover__settings"
          aria-label={t('profile.settings')}
          onClick={() => openSheet({ kind: 'settings' })}
        >
          <Settings aria-hidden="true" />
        </button>
      </div>

      <section className="profile">
        <div className="profile__avatar">
          <Avatar name={profile.name} src={profile.avatar || undefined} size={92} />
        </div>
        <h1 className="profile__name">{profile.name}</h1>
        <p className="profile__handle">@{profile.handle}</p>
        {profile.bio && <p className="profile__bio">{profile.bio}</p>}
        <button type="button" className="btn btn--soft" onClick={() => openSheet({ kind: 'editProfile' })}>
          {t('profile.edit')}
        </button>

        <dl className="stats">
          <div>
            <dd>{compact(posts.length)}</dd>
            <dt>{t('profile.posts')}</dt>
          </div>
          <div>
            <dd>0</dd>
            <dt>{t('profile.followers')}</dt>
          </div>
          <div>
            <dd>{compact(state.following.length)}</dd>
            <dt>{t('profile.following')}</dt>
          </div>
        </dl>

        <div className="tabs" role="tablist">
          <button type="button" role="tab" aria-selected={tab === 'posts'} className={tab === 'posts' ? 'is-active' : ''} onClick={() => setTab('posts')}>
            <Camera size={17} aria-hidden="true" />
            {t('profile.tabPosts')}
          </button>
          <button type="button" role="tab" aria-selected={tab === 'saved'} className={tab === 'saved' ? 'is-active' : ''} onClick={() => setTab('saved')}>
            <Bookmark size={17} aria-hidden="true" />
            {t('profile.tabSaved')}
          </button>
        </div>

        {shown.length === 0 ? (
          tab === 'posts' ? (
            <EmptyState
              icon={<Camera size={30} />}
              title={t('profile.emptyPosts')}
              body={t('profile.emptyPostsBody')}
              action={
                <button type="button" className="btn btn--primary" onClick={() => openSheet({ kind: 'create' })}>
                  {t('create.publish')}
                </button>
              }
            />
          ) : (
            <EmptyState icon={<Heart size={30} />} title={t('profile.emptySaved')} body={t('profile.emptySavedBody')} />
          )
        ) : (
          <ul className="grid">
            {shown.map((p) => (
              <li key={p.id}>
                <button type="button" className="grid__item" aria-label={t('profile.openPost')} onClick={() => openSheet({ kind: 'post', postId: p.id })}>
                  <SafeImage src={sized(p.image, 400)} alt="" ratio={1} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
