import { useState } from 'react';
import { BadgeCheck, Bookmark, Check, Heart, MessageCircle, Plus, Send, Users } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { EmptyState } from '../components/Common';
import { SafeImage } from '../components/SafeImage';
import { usePostActions } from '../components/PostCard';
import { sized } from '../data/seed';
import { useT } from '../i18n';
import { compact } from '../lib/format';
import { useFeed, useStore } from '../store/AppStore';
import { useUi } from '../ui/UiContext';
import type { Post } from '../types';

function ReelItem({ post, first }: { post: Post; first: boolean }) {
  const t = useT();
  const { state, dispatch } = useStore();
  const { openSheet } = useUi();
  const { author, liked, saved, commentTotal, likeTotal, toggleLike, toggleSave, share } = usePostActions(post);
  const isMine = post.authorId === 'me';
  const following = state.following.includes(post.authorId);

  return (
    <section className="reel">
      <SafeImage
        className="reel__img"
        src={sized(post.image, 1080)}
        alt={t('post.imageAlt', { name: author.name })}
        eager={first}
      />
      <div className="reel__scrim" aria-hidden="true" />

      <div className="reel__side">
        <button
          type="button"
          className={`reel__btn${liked ? ' is-liked' : ''}`}
          aria-pressed={liked}
          aria-label={liked ? t('post.unlike') : t('post.like')}
          onClick={toggleLike}
        >
          <Heart aria-hidden="true" fill={liked ? 'currentColor' : 'none'} />
          <span>{compact(likeTotal)}</span>
        </button>
        <button
          type="button"
          className="reel__btn"
          aria-label={t('post.comment')}
          onClick={() => openSheet({ kind: 'comments', postId: post.id })}
        >
          <MessageCircle aria-hidden="true" />
          <span>{compact(commentTotal)}</span>
        </button>
        <button
          type="button"
          className={`reel__btn${saved ? ' is-saved' : ''}`}
          aria-pressed={saved}
          aria-label={saved ? t('post.unsave') : t('post.save')}
          onClick={toggleSave}
        >
          <Bookmark aria-hidden="true" fill={saved ? 'currentColor' : 'none'} />
        </button>
        <button type="button" className="reel__btn" aria-label={t('post.share')} onClick={share}>
          <Send aria-hidden="true" />
        </button>
      </div>

      <div className="reel__info">
        <div className="reel__author">
          <Avatar name={author.name} hue={author.hue} src={author.avatar} size={36} />
          <strong>
            {author.name}
            {author.verified && <BadgeCheck size={15} aria-label={t('common.verified')} />}
          </strong>
          {!isMine && (
            <button
              type="button"
              className={`reel__follow${following ? ' is-following' : ''}`}
              aria-pressed={following}
              onClick={() => dispatch({ type: 'toggleFollow', id: post.authorId })}
            >
              {following ? <Check size={14} aria-hidden="true" /> : <Plus size={14} aria-hidden="true" />}
              {following ? t('reels.followingBtn') : t('reels.follow')}
            </button>
          )}
        </div>
        {post.caption && <p>{post.caption}</p>}
        {post.tags.length > 0 && <small>{post.tags.map((tag) => `#${tag}`).join(' ')}</small>}
      </div>
    </section>
  );
}

export function ReelsScreen() {
  const t = useT();
  const { state } = useStore();
  const feed = useFeed();
  const [tab, setTab] = useState<'forYou' | 'following'>('forYou');
  const items = tab === 'following' ? feed.filter((p) => state.following.includes(p.authorId)) : feed;

  return (
    <div className="reels-wrap">
      <div className="reels-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          aria-selected={tab === 'following'}
          className={tab === 'following' ? 'is-active' : ''}
          onClick={() => setTab('following')}
        >
          {t('reels.following')}
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === 'forYou'}
          className={tab === 'forYou' ? 'is-active' : ''}
          onClick={() => setTab('forYou')}
        >
          {t('reels.forYou')}
        </button>
      </div>

      {items.length === 0 ? (
        <div className="reels-empty">
          <EmptyState icon={<Users size={30} />} title={t('reels.emptyTitle')} body={t('reels.emptyBody')} />
        </div>
      ) : (
        <div className="reels" key={tab}>
          {items.map((post, i) => (
            <ReelItem key={post.id} post={post} first={i === 0} />
          ))}
        </div>
      )}
    </div>
  );
}
