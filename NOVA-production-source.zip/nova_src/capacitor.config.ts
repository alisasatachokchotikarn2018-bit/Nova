import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  // Set this to your own reverse-domain id before the first Play upload — it can never change afterwards.
  appId: 'app.nova.social',
  appName: 'NOVA',
  webDir: 'dist',
  backgroundColor: '#ffffff',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: false,
    webContentsDebuggingEnabled: false,
  },
};

export default config;
