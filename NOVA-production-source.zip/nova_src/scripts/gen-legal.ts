/**
 * Generates standalone privacy.html / terms.html from the in-app legal text, so the public
 * URL (needed for store listings) and the in-app text can never drift apart.
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import { LEGAL, type LegalKind } from '../src/i18n/legal.ts';

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function page(kind: LegalKind): string {
  const th = LEGAL[kind].th;
  const en = LEGAL[kind].en;
  const block = (doc: typeof th, lang: string) => `
    <section lang="${lang}">
      <h1>${esc(doc.title)}</h1>
      <p class="meta">${esc(doc.updated)}</p>
      ${doc.sections.map((s) => `<h2>${esc(s.h)}</h2><p>${esc(s.p)}</p>`).join('\n      ')}
    </section>`;
  return `<!doctype html>
<html lang="th">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${esc(th.title)} · ${esc(en.title)} — NOVA</title>
    <style>
      :root { color-scheme: light dark; }
      body { font: 16px/1.6 system-ui, 'Noto Sans Thai', 'Leelawadee UI', sans-serif; max-width: 720px; margin: 0 auto; padding: 24px 20px 64px; }
      h1 { font-size: 26px; margin: 40px 0 4px; }
      h2 { font-size: 18px; margin: 24px 0 4px; }
      .meta { opacity: 0.7; margin: 0 0 16px; }
      hr { margin: 48px 0; border: 0; border-top: 1px solid rgba(128, 128, 128, 0.4); }
      a { color: #0a6fc2; }
    </style>
  </head>
  <body>
    <p><a href="/">← NOVA</a></p>${block(th, 'th')}
    <hr />${block(en, 'en')}
  </body>
</html>
`;
}

mkdirSync(new URL('../public/', import.meta.url), { recursive: true });
writeFileSync(new URL('../public/privacy.html', import.meta.url), page('privacy'));
writeFileSync(new URL('../public/terms.html', import.meta.url), page('terms'));
console.log('legal pages generated');
